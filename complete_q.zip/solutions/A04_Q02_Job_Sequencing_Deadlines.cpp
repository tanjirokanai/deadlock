// Problem: Job Sequencing with Deadlines
// Assignment: 4
// Question: 2
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Schedule tasks with a deadline and payout to maximize total payout. Max one task per day.

Approach:
Greedy choice: consider tasks in decreasing order of payout. Assign to the latest possible free day.
*/

#include <bits/stdc++.h>
using namespace std;
struct Task { int id, deadline, payout; };
int main() {
    int slots, n;
    cin >> slots >> n;
    vector<Task> t(n);
    for (int i = 0; i < n; i++) {
        t[i].id = i + 1;
        cin >> t[i].deadline >> t[i].payout;
    }
    sort(t.begin(), t.end(), [](const Task& a, const Task& b) {
        return a.payout > b.payout;
    });
    vector<int> slotTask(slots + 1, 0), payoutOf(slots + 1, 0);
    int total = 0, done = 0;
    for (const Task& x : t) {
        for (int d = min(x.deadline, slots); d >= 1; d--) {
            if (slotTask[d] == 0) {
                slotTask[d] = x.id;
                payoutOf[d] = x.payout;
                total += x.payout;
                done++;
                break;
            }
        }
    }
    cout << "Total payout = " << total << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 3 5 ... Output: Total payout = 270
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A04_Q02_Job_Sequencing_Deadlines.cpp -o A04_Q02_Job_Sequencing_Deadlines.exe && .\A04_Q02_Job_Sequencing_Deadlines.exe
