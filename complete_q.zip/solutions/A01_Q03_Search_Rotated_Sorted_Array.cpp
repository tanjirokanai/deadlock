// Problem: Search in a Rotated Sorted Array
// Assignment: 1
// Question: 3
// Domain: 09_Binary_Search

/* Problem Statement:
Given a sorted array of n integers that has been rotated an unknown number of times, write code to find an element in the array.

Approach:
Modified binary search. At any point, at least one half of the array is guaranteed to be normally sorted.
*/

#include <bits/stdc++.h>
using namespace std;
int searchRotated(vector<int>& arr, int target) {
    int lo = 0, hi = arr.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] == target) return mid;
        if (arr[lo] <= arr[mid]) {
            if (arr[lo] <= target && target < arr[mid]) hi = mid - 1;
            else lo = mid + 1;
        } else {
            if (arr[mid] < target && target <= arr[hi]) lo = mid + 1;
            else hi = mid - 1;
        }
    }
    return -1;
}
int main() {
    vector<int> arr = {15, 16, 19, 20, 25, 1, 3, 4, 5, 7, 10, 14};
    cout << searchRotated(arr, 5);
}

/* Sample Input & Output:
Target: 5
Output: 8
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A01_Q03_Search_Rotated_Sorted_Array.cpp -o A01_Q03_Search_Rotated_Sorted_Array.exe && .\A01_Q03_Search_Rotated_Sorted_Array.exe
