// Problem: Rank of a Number in a Data Stream
// Assignment: 1
// Question: 8
// Domain: 12_Trees

/* Problem Statement:
Implement track(int x) and getRankOfNumber(int x), which returns the number of values less than or equal to x (not including x itself).

Approach:
Use a Binary Search Tree where every node additionally stores the size of its left subtree.
*/

#include <bits/stdc++.h>
using namespace std;
struct Node {
    int data;
    int leftSize = 0;
    Node *left = nullptr, *right = nullptr;
    Node(int d) : data(d) {}
};
class RankTracker {
    Node* root = nullptr;
    Node* insert(Node* node, int x) {
        if (!node) return new Node(x);
        if (x <= node->data) {
            node->leftSize++;
            node->left = insert(node->left, x);
        } else {
            node->right = insert(node->right, x);
        }
        return node;
    }
    int rank(Node* node, int x) {
        if (!node) return -1;
        if (x == node->data) return node->leftSize;
        if (x < node->data) return rank(node->left, x);
        int r = rank(node->right, x);
        return (r == -1) ? -1 : node->leftSize + 1 + r;
    }
public:
    void track(int x) { root = insert(root, x); }
    int getRankOfNumber(int x) { return rank(root, x); }
};
int main() {
    RankTracker rt;
    for (int x : {5, 1, 4, 4, 5, 9, 7, 13, 3}) rt.track(x);
    cout << rt.getRankOfNumber(1) << "\n";
    cout << rt.getRankOfNumber(3) << "\n";
    cout << rt.getRankOfNumber(4) << "\n";
}

/* Sample Input & Output:
Output:
0
1
3
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A01_Q08_Rank_Of_Number.cpp -o A01_Q08_Rank_Of_Number.exe && .\A01_Q08_Rank_Of_Number.exe
