# Folder Guide
Organized by algorithmic domain.