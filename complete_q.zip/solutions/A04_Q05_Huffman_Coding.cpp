// Problem: Huffman Coding
// Assignment: 4
// Question: 5
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Generate optimal prefix codes so that heavy channels get the shortest codes.

Approach:
Use a min-heap to build a Huffman Tree, merging lowest frequency nodes until 1 root remains.
*/

#include <bits/stdc++.h>
using namespace std;
struct Node {
    long long freq;
    int order;
    int left, right;
    string name;
};
vector<Node> tree;
struct Cmp {
    bool operator()(int a, int b) const {
        if (tree[a].freq != tree[b].freq) return tree[a].freq > tree[b].freq;
        return tree[a].order > tree[b].order;
    }
};
void buildCodes(int u, const string& code, map<string, string>& codes) {
    if (tree[u].left == -1) {
        codes[tree[u].name] = code.empty() ? "0" : code;
        return;
    }
    buildCodes(tree[u].left, code + "0", codes);
    buildCodes(tree[u].right, code + "1", codes);
}
int main() {
    int n;
    cin >> n;
    vector<string> names(n);
    vector<long long> freq(n);
    priority_queue<int, vector<int>, Cmp> pq;
    for (int i = 0; i < n; i++) {
        cin >> names[i] >> freq[i];
        tree.push_back({freq[i], i, -1, -1, names[i]});
        pq.push(i);
    }
    int counter = n;
    while (pq.size() > 1) {
        int a = pq.top(); pq.pop();
        int b = pq.top(); pq.pop();
        tree.push_back({tree[a].freq + tree[b].freq, counter++, a, b, ""});
        pq.push(tree.size() - 1);
    }
    map<string, string> codes;
    buildCodes(pq.top(), "", codes);
    for (int i=0; i<n; i++) cout << names[i] << " = " << codes[names[i]] << "\n";
    return 0;
}

/* Sample Input & Output:
Input: 2
X 70
Y 30
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A04_Q05_Huffman_Coding.cpp -o A04_Q05_Huffman_Coding.exe && .\A04_Q05_Huffman_Coding.exe
