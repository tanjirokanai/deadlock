// Problem: The Skyline Problem
// Assignment: 3
// Question: 3
// Domain: 19_Advanced_Algorithms

/* Problem Statement:
Compute the skyline (visible strips) formed by a set of buildings.

Approach:
Divide and conquer: compute skyline of halves, then merge tracking current height of both skylines.
*/

#include <bits/stdc++.h>
using namespace std;
struct Building { int left, ht, right; };
typedef vector<pair<int, int>> Skyline;
Skyline mergeSkylines(const Skyline& A, const Skyline& B) {
    Skyline res;
    int i = 0, j = 0;
    int h1 = 0, h2 = 0;
    while (i < (int)A.size() && j < (int)B.size()) {
        int x;
        if (A[i].first < B[j].first) { x = A[i].first; h1 = A[i].second; i++; }
        else if (B[j].first < A[i].first) { x = B[j].first; h2 = B[j].second; j++; }
        else { x = A[i].first; h1 = A[i].second; h2 = B[j].second; i++; j++; }
        int h = max(h1, h2);
        if (res.empty() || res.back().second != h) res.push_back({x, h});
    }
    while (i < (int)A.size()) {
        if (res.empty() || res.back().second != A[i].second) res.push_back(A[i]);
        i++;
    }
    while (j < (int)B.size()) {
        if (res.empty() || res.back().second != B[j].second) res.push_back(B[j]);
        j++;
    }
    return res;
}
Skyline solve(const vector<Building>& b, int lo, int hi) {
    if (lo == hi) return {{b[lo].left, b[lo].ht}, {b[lo].right, 0}};
    int mid = lo + (hi - lo) / 2;
    return mergeSkylines(solve(b, lo, mid), solve(b, mid + 1, hi));
}
int main() {
    int n;
    cin >> n;
    vector<Building> b(n);
    for (int i = 0; i < n; i++) cin >> b[i].left >> b[i].ht >> b[i].right;
    Skyline sky = solve(b, 0, n - 1);
    cout << "Skyline: ";
    for (size_t i = 0; i < sky.size(); i++) {
        cout << "(" << sky[i].first << ", " << sky[i].second << ")";
        if (i + 1 < sky.size()) cout << ", ";
    }
    cout << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 2
2 4 6
8 3 10
Output: Skyline: (2, 4), (6, 0), (8, 3), (10, 0)
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A03_Q03_Skyline_Problem.cpp -o A03_Q03_Skyline_Problem.exe && .\A03_Q03_Skyline_Problem.exe
