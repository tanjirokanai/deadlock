// Problem: Sparse Search
// Assignment: 1
// Question: 5
// Domain: 09_Binary_Search

/* Problem Statement:
Given a sorted array of strings which is interspersed with empty strings, write a method to find the location of a given string.

Approach:
Modified binary search. If arr[mid] is empty, scan outward (left and right) from mid to find the nearest non-empty string.
*/

#include <bits/stdc++.h>
using namespace std;
int sparseSearch(vector<string>& arr, const string& target, int lo, int hi) {
    if (lo > hi) return -1;
    int mid = lo + (hi - lo) / 2;
    if (arr[mid].empty()) {
        int left = mid - 1, right = mid + 1;
        while (true) {
            if (left < lo && right > hi) return -1;
            if (right <= hi && !arr[right].empty()) { mid = right; break; }
            if (left >= lo && !arr[left].empty())    { mid = left;  break; }
            left--; right++;
        }
    }
    if (arr[mid] == target) return mid;
    if (arr[mid] < target) return sparseSearch(arr, target, mid + 1, hi);
    else return sparseSearch(arr, target, lo, mid - 1);
}
int main() {
    vector<string> arr = {"at", "", "", "ball", "", "", "car", "", "", "dad", "", ""};
    cout << sparseSearch(arr, "ball", 0, arr.size() - 1);
}

/* Sample Input & Output:
Target: "ball"
Output: 4
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A01_Q05_Sparse_Search.cpp -o A01_Q05_Sparse_Search.exe && .\A01_Q05_Sparse_Search.exe
