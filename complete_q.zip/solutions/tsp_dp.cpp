// Problem: Traveling Salesperson Problem (TSP)
// Original file: A07_Q20.cpp

/* Problem Statement:
Traveling Salesperson Problem (TSP)

Approach:
Use DP with bitmask to find shortest tour visiting all nodes.
*/

#include <algorithm>
using namespace std;
int main()
{
    int n;
    cin >> n;
    vector<vector<int>> dist(n, vector<int>(n));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> dist[i][j];
        }
    }
    int base;
    cin >> base;
    int totalMasks = 1 << n;
    const int INF = INT_MAX / 2;
    vector<vector<int>> dp(totalMasks, vector<int>(n, INF));
    vector<vector<int>> parent(totalMasks, vector<int>(n, -1));
    dp[1 << base][base] = 0;
    for (int mask = 0; mask < totalMasks; mask++)
    {
        for (int current = 0; current < n; current++)
        {
            if (dp[mask][current] == INF)
                continue;
            if ((mask & (1 << current)) == 0)
                continue;
            for (int next = 0; next < n; next++)
            {
                if (mask & (1 << next))
                    continue;
                int newMask = mask | (1 << next);
                int newCost =
                    dp[mask][current] + dist[current][next];
                if (newCost < dp[newMask][next])
                {
                    dp[newMask][next] = newCost;
                    parent[newMask][next] = current;
                }
            }
        }
    }
    int fullMask = totalMasks - 1;
    int minCost = INF;
    int last = -1;
    for (int current = 0; current < n; current++)
    {
        int routeCost =
            dp[fullMask][current] + dist[current][base];
        if (routeCost < minCost)
        {
            minCost = routeCost;
            last = current;
        }
    }
    vector<int> route;
    int mask = fullMask;
    while (last != -1)
    {
        route.push_back(last);
        int previous = parent[mask][last];
        if (last == base && mask == (1 << base))
            break;
        mask = mask ^ (1 << last);
        last = previous;
    }
    reverse(route.begin(), route.end());
    cout << "Minimum route distance = "
         << minCost << endl;
    cout << "Optimal route: ";
    for (int city : route)
        cout << city << " -> ";
    cout << base << endl;
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra tsp_dp.cpp -o tsp_dp.exe && .\tsp_dp.exe
