// Problem: Optimal Binary Search Tree
// Original file: A07_Q10.cpp

/* Problem Statement:
Optimal Binary Search Tree

Approach:
Use DP to minimize search cost based on frequencies.
*/

#include <climits>
using namespace std;
void printTree(int i, int j,
               vector<vector<int> >& root,
               vector<int>& freq,
               string relation)
{
    if (i > j)
        return;
    int r = root[i][j];
    cout << relation << "Key " << r
         << " (Frequency = " << freq[r] << ")" << endl;
    printTree(i, r - 1, root, freq, "    Left -> ");
    printTree(r + 1, j, root, freq, "    Right -> ");
}
int main()
{
    int n;
    cin >> n;
    vector<int> freq(n + 1);
    for (int i = 1; i <= n; i++)
        cin >> freq[i];
    vector<vector<int> > cost(n + 2,
                              vector<int>(n + 2, 0));
    vector<vector<int> > root(n + 2,
                              vector<int>(n + 2, 0));
    vector<int> prefix(n + 1, 0);
    for (int i = 1; i <= n; i++)
        prefix[i] = prefix[i - 1] + freq[i];
    for (int length = 1; length <= n; length++)
    {
        for (int i = 1; i + length - 1 <= n; i++)
        {
            int j = i + length - 1;
            int sum = prefix[j] - prefix[i - 1];
            cost[i][j] = INT_MAX;
            for (int r = i; r <= j; r++)
            {
                int leftCost = 0;
                int rightCost = 0;
                if (r > i)
                    leftCost = cost[i][r - 1];
                if (r < j)
                    rightCost = cost[r + 1][j];
                int currentCost =
                    leftCost + rightCost + sum;
                if (currentCost < cost[i][j])
                {
                    cost[i][j] = currentCost;
                    root[i][j] = r;
                }
            }
        }
    }
    cout << "Minimum expected search cost = "
         << cost[1][n] << endl;
    cout << "\nOptimal BST Structure:\n";
    printTree(1, n, root, freq, "Root -> ");
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra optimal_bst.cpp -o optimal_bst.exe && .\optimal_bst.exe
