// Problem: Corporate Office Meeting Rooms
// Assignment: 5
// Question: 3
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Determine the minimum number of rooms needed so that no two meetings overlap.

Approach:
Separate and sort start and end times. Two pointers sweep to increment/decrement active rooms.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    vector<pair<int,int>> meetings = {{900,1000},{930,1330},{1200,1300}};
    int n = meetings.size();
    vector<int> starts(n), ends(n);
    for (int i = 0; i < n; i++) { starts[i] = meetings[i].first; ends[i] = meetings[i].second; }
    sort(starts.begin(), starts.end());
    sort(ends.begin(), ends.end());
    int rooms = 0, maxRooms = 0, i = 0, j = 0;
    while (i < n) {
        if (starts[i] < ends[j]) { rooms++; i++; }
        else { rooms--; j++; }
        maxRooms = max(maxRooms, rooms);
    }
    cout << "Minimum meeting rooms required: " << maxRooms << endl;
    return 0;
}

/* Sample Input & Output:
Data hardcoded.
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A05_Q03_Meeting_Rooms.cpp -o A05_Q03_Meeting_Rooms.exe && .\A05_Q03_Meeting_Rooms.exe
