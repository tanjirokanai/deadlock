// Problem: Vertex Cover Approximation
// Original file: A10_Q04.cpp

/* Problem Statement:
Vertex Cover Approximation

Approach:
Greedily select endpoints of uncovered edges.
*/

#include <iostream>
using namespace std;
int main() {
    int n, graph[20][20];
    bool covered[20][20] = {};
    bool selected[20] = {};
    cout << "Enter number of vertices: ";
    cin >> n;
    if (n < 1 || n > 20) {
        cout << "Invalid number of vertices\n";
        return 0;
    }
    cout << "Enter adjacency matrix:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> graph[i][j];
        }
    }
    // Select both endpoints of an uncovered edge
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (graph[i][j] == 1 && !covered[i][j]) {
                selected[i] = true;
                selected[j] = true;
                // Mark edges incident to either endpoint
                for (int k = 0; k < n; k++) {
                    if (graph[i][k] == 1)
                        covered[i][k] = covered[k][i] = true;
                    if (graph[j][k] == 1)
                        covered[j][k] = covered[k][j] = true;
                }
            }
        }
    }
    int count = 0;
    cout << "Approximate Vertex Cover: ";
    for (int i = 0; i < n; i++) {
        if (selected[i]) {
            cout << i + 1 << " ";
            count++;
        }
    }
    cout << "\nSize of Vertex Cover: " << count << endl;
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra vertex_cover_approx.cpp -o vertex_cover_approx.exe && .\vertex_cover_approx.exe
