// Problem: Esports Arena Match Scheduling
// Assignment: 5
// Question: 2
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Select the maximum number of non-overlapping matches that can be hosted.

Approach:
Sort by finish time (ascending), greedily pick the next activity that fits.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    vector<pair<int,int>> matches = {{1,3},{2,5},{0,6},{5,8},{4,9}};
    int n = matches.size();
    vector<int> idx(n);
    iota(idx.begin(), idx.end(), 0);
    sort(idx.begin(), idx.end(), [&](int a, int b) {
        return matches[a].second < matches[b].second;
    });
    int lastEnd = -1, count = 0;
    for (int i : idx) {
        if (matches[i].first >= lastEnd) {
            count++;
            lastEnd = matches[i].second;
        }
    }
    cout << "Max non-overlapping matches: " << count << endl;
    return 0;
}

/* Sample Input & Output:
Data hardcoded.
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A05_Q02_Activity_Selection.cpp -o A05_Q02_Activity_Selection.exe && .\A05_Q02_Activity_Selection.exe
