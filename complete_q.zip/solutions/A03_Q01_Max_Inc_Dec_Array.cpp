// Problem: Maximum of an Increasing-then-Decreasing Array
// Assignment: 3
// Question: 1
// Domain: 09_Binary_Search

/* Problem Statement:
Find the maximum element of an array that first increases and then decreases, in O(log n) time.

Approach:
Compare the middle element a[mid] with its right neighbour a[mid+1]. Move left or right depending on trend.
*/

#include <bits/stdc++.h>
using namespace std;
int findPeak(const vector<int>& a, int lo, int hi) {
    if (lo == hi) return lo;
    int mid = lo + (hi - lo) / 2;
    if (a[mid] < a[mid + 1]) return findPeak(a, mid + 1, hi);
    return findPeak(a, lo, mid);
}
int main() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    int idx = findPeak(a, 0, n - 1);
    cout << "Maximum element = " << a[idx] << " at index " << idx << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 6
1 3 8 12 4 2
Output: Maximum element = 12 at index 3
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A03_Q01_Max_Inc_Dec_Array.cpp -o A03_Q01_Max_Inc_Dec_Array.exe && .\A03_Q01_Max_Inc_Dec_Array.exe
