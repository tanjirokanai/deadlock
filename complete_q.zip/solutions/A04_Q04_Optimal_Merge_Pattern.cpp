// Problem: Optimal Merge Pattern
// Assignment: 4
// Question: 4
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Find the merge order that minimises the total cost of merging all files into one.

Approach:
Greedy choice: always merge the two smallest files using a Min-Heap (priority queue).
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    priority_queue<int, vector<int>, greater<int>> pq;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        pq.push(x);
    }
    long long totalCost = 0;
    while (pq.size() > 1) {
        int a = pq.top(); pq.pop();
        int b = pq.top(); pq.pop();
        int merged = a + b;
        totalCost += merged;
        pq.push(merged);
    }
    cout << "Minimum total merge cost = " << totalCost << " MB\n";
    return 0;
}

/* Sample Input & Output:
Input: 4
35 110 180 8
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A04_Q04_Optimal_Merge_Pattern.cpp -o A04_Q04_Optimal_Merge_Pattern.exe && .\A04_Q04_Optimal_Merge_Pattern.exe
