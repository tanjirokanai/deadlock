// Problem: Hamiltonian Cycle
// Original file: A10_Q03.cpp

/* Problem Statement:
Hamiltonian Cycle

Approach:
Use backtracking to find a cycle visiting every vertex exactly once.
*/

#include <iostream>
using namespace std;
int n, graph[20][20], path[20];
bool isSafe(int v, int pos) {
    if (graph[path[pos - 1]][v] == 0)
        return false;
    for (int i = 0; i < pos; i++) {
        if (path[i] == v)
            return false;
    }
    return true;
}
bool solve(int pos) {
    if (pos == n)
        return graph[path[n - 1]][path[0]] == 1;
    for (int v = 1; v < n; v++) {
        if (isSafe(v, pos)) {
            path[pos] = v;
            if (solve(pos + 1))
                return true;
            path[pos] = -1;
        }
    }
    return false;
}
int main() {
    cout << "Enter number of vertices: ";
    cin >> n;
    if (n < 1 || n > 20) {
        cout << "Invalid number of vertices\n";
        return 0;
    }
    cout << "Enter adjacency matrix:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> graph[i][j];
        }
    }
    for (int i = 0; i < n; i++)
        path[i] = -1;
    path[0] = 0;
    if (solve(1)) {
        cout << "Hamiltonian Cycle: ";
        for (int i = 0; i < n; i++)
            cout << path[i] + 1 << " ";
        cout << path[0] + 1 << endl;
    } else {
        cout << "No Hamiltonian Cycle exists\n";
    }
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra hamiltonian_cycle.cpp -o hamiltonian_cycle.exe && .\hamiltonian_cycle.exe
