// Problem: Grid Unique Paths with Obstacles
// Original file: A06_Q01.cpp

/* Problem Statement:
Grid Unique Paths with Obstacles

Approach:
Use DP table to count paths avoiding obstacles.
*/

#include <iostream>
#include <vector>
using namespace std;
int countPaths(vector<vector<int>>& grid) {
    int m = grid.size();
    int n = grid[0].size();
    vector<vector<int>> dp(m, vector<int>(n, 0));
    // If starting cell is an obstacle
    if (grid[0][0] == 1)
        return 0;
    dp[0][0] = 1;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            // Skip the starting cell
            if (i == 0 && j == 0)
                continue;
            // Cannot pass through obstacle
            if (grid[i][j] == 1) {
                dp[i][j] = 0;
            }
            else {
                // Add paths from top
                if (i > 0)
                    dp[i][j] += dp[i - 1][j];
                // Add paths from left
                if (j > 0)
                    dp[i][j] += dp[i][j - 1];
            }
        }
    }
    return dp[m - 1][n - 1];
}
int main() {
    int m, n;
    cout << "Enter rows and columns: ";
    cin >> m >> n;
    vector<vector<int>> grid(m, vector<int>(n));
    cout << "Enter grid (0 = free, 1 = obstacle):\n";
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cin >> grid[i][j];
        }
    }
    int result = countPaths(grid);
    cout << "Number of valid paths: " << result << endl;
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra unique_paths_obstacles.cpp -o unique_paths_obstacles.exe && .\unique_paths_obstacles.exe
