// Problem: N-Queens Problem
// Original file: A10_Q01.cpp

/* Problem Statement:
N-Queens Problem

Approach:
Use backtracking to place N queens safely on board.
*/

#include <iostream>
#include <vector>
#include <string>
using namespace std;
class Solution {
public:
    bool isSafe(vector<string>& board, int row, int col, int n) {
        // Check same row
        for (int j = 0; j < n; j++) {
            if (board[row][j] == 'Q')
                return false;
        }
        // Check same column
        for (int i = 0; i < n; i++) {
            if (board[i][col] == 'Q')
                return false;
        }
        // Check upper-right diagonal
        for (int i = row, j = col;
             i >= 0 && j < n; i--, j++) {
            if (board[i][j] == 'Q')
                return false;
        }
        // Check upper-left diagonal
        for (int i = row, j = col;
             i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 'Q')
                return false;
        }
        return true;
    }
    void nQueens(vector<string>& board, int row, int n,
                 vector<vector<string>>& ans) {
        if (row == n) {
            ans.push_back(board);
            return;
        }
        for (int col = 0; col < n; col++) {
            if (isSafe(board, row, col, n)) {
                board[row][col] = 'Q';
                nQueens(board, row + 1, n, ans);
                board[row][col] = '.';
            }
        }
    }
    vector<vector<string>> solveNQueens(int n) {
        vector<string> board(n, string(n, '.'));
        vector<vector<string>> ans;
        nQueens(board, 0, n, ans);
        return ans;
    }
};
int main() {
    int n;
    cout << "Enter N: ";
    cin >> n;
    Solution obj;
    vector<vector<string>> ans = obj.solveNQueens(n);
    int count = 0;
    for (auto board : ans) {
        cout << "\nSolution " << ++count << ":\n";
        for (auto row : board)
            cout << row << endl;
    }
    cout << "\nTotal solutions: " << count << endl;
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra n_queens_backtracking_v2.cpp -o n_queens_backtracking_v2.exe && .\n_queens_backtracking_v2.exe
