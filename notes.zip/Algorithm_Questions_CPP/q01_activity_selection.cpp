/*
QUESTION 1: Activity Selection (Greedy Technique)

Scenario Description:
A conference hall receives N meeting requests, each with a start and finish time. Only one meeting can use the hall at a time. Select the maximum number of non-overlapping meetings.

Input Format:
• Line 1: N
• Next N lines: start finish

Output Format:
• Line 1: Maximum number of meetings
• Line 2: Selected meeting numbers (1-based, in order of finish time)

Input:
6
1 4
3 5
0 6
5 7
3 9
5 9

Expected Output:
Maximum meetings: 2
Selected meetings: 1 4
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin>>n;
    vector<array<int,3>> a(n);
    for(int i=0;i<n;i++){ cin>>a[i][0]>>a[i][1]; a[i][2]=i+1; }
    stable_sort(a.begin(),a.end(),[](const array<int,3>&x,const array<int,3>&y){return x[1]<y[1];});
    int last=-1; vector<int> sel;
    for(auto&t:a) if(t[0]>=last){ sel.push_back(t[2]); last=t[1]; }
    cout<<"Maximum meetings: "<<sel.size()<<"\n";
    cout<<"Selected meetings:";
    for(int x:sel) cout<<" "<<x;
    cout<<"\n";
}
