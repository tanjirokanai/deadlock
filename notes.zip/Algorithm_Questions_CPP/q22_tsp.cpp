/*
QUESTION 22: Traveling Salesperson Problem (DP / Held-Karp)

Scenario Description:
A salesperson must visit N cities exactly once and return to the start city with minimum total distance.

Input Format:
• Line 1: N
• Next N lines: N x N distance matrix

Output Format:
• Line 1: Minimum tour cost
• Line 2: Tour starting from city 1

Input:
4
0 10 15 20
10 0 35 25
15 35 0 30
20 25 30 0

Expected Output:
Minimum tour cost: 80
Tour: 1 -> 3 -> 4 -> 2 -> 1
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin>>n; vector<vector<int>> D(n,vector<int>(n));
    for(auto&r:D) for(auto&x:r) cin>>x;
    const long long INF=1000000000LL; int N=1<<n;
    vector<vector<long long>> dp(N,vector<long long>(n,INF));
    vector<vector<int>> pr(N,vector<int>(n,-1));
    dp[1][0]=0;
    for(int m=0;m<N;m++) for(int i=0;i<n;i++) if(dp[m][i]<INF)
        for(int j=0;j<n;j++)
            if(!((m>>j)&1) && dp[m][i]+D[i][j]<dp[m|(1<<j)][j]){
                dp[m|(1<<j)][j]=dp[m][i]+D[i][j]; pr[m|(1<<j)][j]=i;
            }
    long long best=INF; int last=0;
    for(int i=1;i<n;i++)
        if(dp[N-1][i]+D[i][0]<best){ best=dp[N-1][i]+D[i][0]; last=i; }
    vector<int> t; int m=N-1,c=last;
    while(c!=-1){ t.push_back(c+1); int p=pr[m][c]; m^=(1<<c); c=p; }
    reverse(t.begin(),t.end()); t.push_back(1);
    cout<<"Minimum tour cost: "<<best<<"\n";
    cout<<"Tour: ";
    for(size_t i=0;i<t.size();i++){ if(i) cout<<" -> "; cout<<t[i]; }
    cout<<"\n";
}
