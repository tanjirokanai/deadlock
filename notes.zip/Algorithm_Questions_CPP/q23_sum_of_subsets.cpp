/*
QUESTION 23: Sum of Subsets Problem (Backtracking)

Scenario Description:
A cashier has N notes of given values and wants to pay exactly M. Find all subsets of notes whose sum equals M.

Input Format:
• Line 1: N M
• Line 2: N values

Output Format:
• All subsets (in sorted order) summing to M, or 'No subset found'

Input:
6 30
5 10 12 13 15 18

Expected Output:
5 10 15
5 12 13
12 18
*/

#include <bits/stdc++.h>
using namespace std;

int n,M; vector<int> w; vector<vector<int>> res;
void bt(int i,vector<int>&cur,int s,int rem){
    if(s==M){ res.push_back(cur); return; }
    if(i==n||s+w[i]>M||s+rem<M) return;
    cur.push_back(w[i]); bt(i+1,cur,s+w[i],rem-w[i]); cur.pop_back();
    bt(i+1,cur,s,rem-w[i]);
}
int main(){
    cin>>n>>M; w.resize(n); for(auto&x:w) cin>>x;
    sort(w.begin(),w.end());
    vector<int> cur; bt(0,cur,0,accumulate(w.begin(),w.end(),0));
    if(res.empty()){ cout<<"No subset found\n"; return 0; }
    for(auto&r:res){
        for(size_t i=0;i<r.size();i++){ if(i) cout<<" "; cout<<r[i]; }
        cout<<"\n";
    }
}
