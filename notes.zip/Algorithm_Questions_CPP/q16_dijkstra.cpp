/*
QUESTION 16: Dijkstra's Algorithm

Scenario Description:
A delivery company has V depots connected by roads (undirected, positive travel time). Find the shortest time from a source depot to all other depots with the path.

Input Format:
• Line 1: V E
• Next E lines: u v w
• Last line: source

Output Format:
• For each depot: shortest distance and path

Input:
6 8
1 2 7
1 3 9
1 6 14
2 3 10
2 4 15
3 4 11
3 6 2
4 5 6
1

Expected Output:
1 -> 1: dist=0, path=1
1 -> 2: dist=7, path=1-2
1 -> 3: dist=9, path=1-3
1 -> 4: dist=20, path=1-3-4
1 -> 5: dist=26, path=1-3-4-5
1 -> 6: dist=11, path=1-3-6
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int V,E; cin>>V>>E; vector<vector<pair<int,int>>> g(V+1);
    for(int i=0;i<E;i++){ int u,v,w; cin>>u>>v>>w; g[u].push_back({v,w}); g[v].push_back({u,w}); }
    int s; cin>>s; const long long INF=LLONG_MAX/4;
    vector<long long> d(V+1,INF); vector<int> par(V+1,0); d[s]=0;
    priority_queue<pair<long long,int>,vector<pair<long long,int>>,greater<>> h; h.push({0,s});
    while(!h.empty()){
        auto [du,u]=h.top(); h.pop();
        if(du>d[u]) continue;
        for(auto [v,w]:g[u])
            if(du+w<d[v]){ d[v]=du+w; par[v]=u; h.push({d[v],v}); }
    }
    for(int v=1;v<=V;v++){
        cout<<s<<" -> "<<v<<": dist=";
        if(d[v]>=INF){ cout<<"INF, path=none\n"; continue; }
        vector<int> p; for(int x=v;x;x=par[x]) p.push_back(x);
        reverse(p.begin(),p.end());
        cout<<d[v]<<", path=";
        for(size_t i=0;i<p.size();i++){ if(i) cout<<"-"; cout<<p[i]; }
        cout<<"\n";
    }
}
