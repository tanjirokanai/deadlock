/*
QUESTION 6: Huffman Trees / Huffman Coding (Greedy)

Scenario Description:
A messaging app wants to compress text. Given N characters and their frequencies, build a Huffman tree and generate prefix codes that minimise total encoded length.

Input Format:
• Line 1: N
• Next N lines: character frequency

Output Format:
• Codes for each character (sorted by character)
• Last line: Total number of bits

Input:
6
a 45
b 13
c 12
d 16
e 9
f 5

Expected Output:
a : 0
b : 101
c : 100
d : 111
e : 1101
f : 1100
Total bits: 224
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin>>n;
    vector<string> name(n); vector<int> fr(n);
    vector<int> L(n,-1),R(n,-1);
    typedef pair<int,int> pii;
    priority_queue<pii,vector<pii>,greater<pii>> h;
    for(int i=0;i<n;i++){ cin>>name[i]>>fr[i]; h.push({fr[i],i}); }
    while(h.size()>1){
        pii a=h.top(); h.pop(); pii b=h.top(); h.pop();
        int id=L.size(); L.push_back(a.second); R.push_back(b.second);
        h.push({a.first+b.first,id});
    }
    map<string,string> codes;
    function<void(int,string)> walk=[&](int u,string pre){
        if(u<n){ codes[name[u]]=pre.empty()?"0":pre; return; }
        walk(L[u],pre+"0"); walk(R[u],pre+"1");
    };
    walk(h.top().second,"");
    long long tot=0;
    for(int i=0;i<n;i++) tot+=(long long)fr[i]*codes[name[i]].size();
    for(auto&kv:codes) cout<<kv.first<<" : "<<kv.second<<"\n";
    cout<<"Total bits: "<<tot<<"\n";
}
