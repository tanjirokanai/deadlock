Compile & run:  g++ -std=c++17 qXX_name.cpp -o a.out && ./a.out
(then paste the sample input)

01. q01_activity_selection.cpp - Activity Selection (Greedy Technique)
02. q02_container_loading.cpp - Container Loading Problem (Greedy)
03. q03_job_sequencing.cpp - Job Sequencing with Deadlines (Greedy)
04. q04_fractional_knapsack.cpp - Fractional Knapsack Problem (Greedy)
05. q05_optimal_merge.cpp - Optimal Merge Pattern (Greedy)
06. q06_huffman_coding.cpp - Huffman Trees / Huffman Coding (Greedy)
07. q07_optimal_bst.cpp - Optimal Binary Search Tree (Dynamic Programming)
08. q08_lcs.cpp - Longest Common Subsequence (Dynamic Programming)
09. q09_zero_one_knapsack.cpp - 0/1 Knapsack Problem (Dynamic Programming)
10. q10_matrix_chain.cpp - Matrix-Chain Multiplication (Dynamic Programming)
11. q11_rod_cutting.cpp - Rod Cutting Problem (Dynamic Programming)
12. q12_dynamic_table.cpp - Dynamic Tables (Amortized Analysis)
13. q13_aggregate_analysis.cpp - Aggregate Analysis - Binary Counter
14. q14_accounting_method.cpp - Accounting Method - Stack with MULTIPOP
15. q15_potential_method.cpp - Potential Method - Binary Counter
16. q16_dijkstra.cpp - Dijkstra's Algorithm
17. q17_dag_shortest_path.cpp - Single-Source Shortest Paths in a DAG
18. q18_bellman_ford.cpp - The Bellman-Ford Algorithm
19. q19_floyd_warshall.cpp - The Floyd-Warshall Algorithm
20. q20_shortest_path_matrix_mult.cpp - Shortest Paths and Matrix Multiplication
21. q21_vertex_cover_approx.cpp - Approximation Algorithm for NP-Hard Problem - Vertex Cover
22. q22_tsp.cpp - Traveling Salesperson Problem (DP / Held-Karp)
23. q23_sum_of_subsets.cpp - Sum of Subsets Problem (Backtracking)
24. q24_n_queens.cpp - N-Queens Problem (Backtracking)
25. q25_graph_coloring.cpp - Graph Colouring (Backtracking)
26. q26_hamiltonian_verifier.cpp - P, NP, NP-Complete - Certificate Verification (Hamiltonian Cycle)
27. q27_shortest_path_properties.cpp - Proofs of Shortest-Paths Properties - Distance Verifier
