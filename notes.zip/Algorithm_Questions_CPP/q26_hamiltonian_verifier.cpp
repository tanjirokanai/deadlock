/*
QUESTION 26: P, NP, NP-Complete - Certificate Verification (Hamiltonian Cycle)

Scenario Description:
Finding a Hamiltonian cycle is NP-Complete, but VERIFYING a proposed cycle (certificate) takes polynomial time. Given a graph and a candidate sequence of vertices, check whether it is a valid Hamiltonian cycle.

Input Format:
• Line 1: V E
• Next E lines: u v (undirected)
• Last line: V vertices (the certificate)

Output Format:
• VALID or INVALID with the reason

Input:
5 6
1 2
2 3
3 4
4 5
5 1
2 5
1 2 3 4 5

Expected Output:
VALID Hamiltonian cycle
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int V,E; cin>>V>>E; set<pair<int,int>> adj;
    for(int i=0;i<E;i++){ int u,v; cin>>u>>v; adj.insert({u,v}); adj.insert({v,u}); }
    vector<int> c; int x; while(cin>>x) c.push_back(x);
    set<int> st(c.begin(),c.end());
    bool allv=((int)c.size()==V&&(int)st.size()==V&&*st.begin()==1&&*st.rbegin()==V);
    if(!allv){ cout<<"INVALID: not every vertex appears exactly once\n"; return 0; }
    for(int i=0;i<V;i++){
        int a=c[i],b=c[(i+1)%V];
        if(!adj.count({a,b})){ cout<<"INVALID: missing edge ("<<a<<", "<<b<<")\n"; return 0; }
    }
    cout<<"VALID Hamiltonian cycle\n";
}
