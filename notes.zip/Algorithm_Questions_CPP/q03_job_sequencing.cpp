/*
QUESTION 3: Job Sequencing with Deadlines (Greedy)

Scenario Description:
A service centre has N jobs. Each job takes exactly 1 unit of time, has a deadline and gives a profit if finished on or before its deadline. Schedule jobs to maximise total profit.

Input Format:
• Line 1: N
• Next N lines: job_id deadline profit

Output Format:
• Line 1: Jobs selected in slot order
• Line 2: Maximum total profit

Input:
5
J1 2 100
J2 1 19
J3 2 27
J4 1 25
J5 3 15

Expected Output:
Scheduled jobs: J3 J1 J5
Maximum profit: 142
*/

#include <bits/stdc++.h>
using namespace std;

struct Job{ string id; int d,p; };
int main(){
    int n; cin>>n; vector<Job> j(n);
    for(auto&x:j) cin>>x.id>>x.d>>x.p;
    stable_sort(j.begin(),j.end(),[](const Job&a,const Job&b){return a.p>b.p;});
    int md=0; for(auto&x:j) md=max(md,x.d);
    vector<string> slot(md+1,""); int profit=0;
    for(auto&x:j){
        for(int t=min(x.d,md);t>=1;t--)
            if(slot[t].empty()){ slot[t]=x.id; profit+=x.p; break; }
    }
    cout<<"Scheduled jobs:";
    for(int t=1;t<=md;t++) if(!slot[t].empty()) cout<<" "<<slot[t];
    cout<<"\nMaximum profit: "<<profit<<"\n";
}
