/*
QUESTION 10: Matrix-Chain Multiplication (Dynamic Programming)

Scenario Description:
A graphics engine must multiply a chain of N matrices. Matrix i has dimensions p[i-1] x p[i]. Find the parenthesisation with the fewest scalar multiplications.

Input Format:
• Line 1: N
• Line 2: N+1 dimensions p0 p1 ... pN

Output Format:
• Line 1: Minimum number of multiplications
• Line 2: Optimal parenthesisation

Input:
4
10 30 5 60 10

Expected Output:
Minimum multiplications: 5000
Parenthesisation: ((A1 x A2) x (A3 x A4))
*/

#include <bits/stdc++.h>
using namespace std;

int n; vector<vector<int>> s;
string par(int i,int j){
    if(i==j) return "A"+to_string(i);
    return "("+par(i,s[i][j])+" x "+par(s[i][j]+1,j)+")";
}
int main(){
    cin>>n; vector<long long> p(n+1);
    for(auto&x:p) cin>>x;
    vector<vector<long long>> m(n+1,vector<long long>(n+1,0));
    s.assign(n+1,vector<int>(n+1,0));
    for(int len=2;len<=n;len++)
        for(int i=1;i<=n-len+1;i++){
            int j=i+len-1; m[i][j]=LLONG_MAX;
            for(int k=i;k<j;k++){
                long long q=m[i][k]+m[k+1][j]+p[i-1]*p[k]*p[j];
                if(q<m[i][j]){ m[i][j]=q; s[i][j]=k; }
            }
        }
    cout<<"Minimum multiplications: "<<m[1][n]<<"\n";
    cout<<"Parenthesisation: "<<par(1,n)<<"\n";
}
