/*
QUESTION 11: Rod Cutting Problem (Dynamic Programming)

Scenario Description:
A steel factory has a rod of length N and a price list for pieces of length 1..N. Cut the rod to maximise total revenue.

Input Format:
• Line 1: N
• Line 2: N prices (price of length 1..N)

Output Format:
• Line 1: Maximum revenue
• Line 2: Lengths of pieces

Input:
8
1 5 8 9 10 17 17 20

Expected Output:
Maximum revenue: 22
Cuts: 2 6
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin>>n; vector<int> p(n+1,0);
    for(int i=1;i<=n;i++) cin>>p[i];
    vector<int> r(n+1,0),c(n+1,0);
    for(int j=1;j<=n;j++)
        for(int i=1;i<=j;i++)
            if(p[i]+r[j-i]>r[j]){ r[j]=p[i]+r[j-i]; c[j]=i; }
    cout<<"Maximum revenue: "<<r[n]<<"\n";
    cout<<"Cuts:";
    for(int x=n;x>0;x-=c[x]) cout<<" "<<c[x];
    cout<<"\n";
}
