/*
QUESTION 13: Aggregate Analysis - Binary Counter

Scenario Description:
A K-bit binary counter (starting at 0) is incremented N times. Count the bit flips of every increment and use aggregate analysis to find the amortized cost per increment.

Input Format:
• Line 1: K N

Output Format:
• Bit flips for each increment, then total flips and average (aggregate) cost

Input:
4 10

Expected Output:
Increment 1: counter=0001, flips=1
Increment 2: counter=0010, flips=2
Increment 3: counter=0011, flips=1
Increment 4: counter=0100, flips=3
Increment 5: counter=0101, flips=1
Increment 6: counter=0110, flips=2
Increment 7: counter=0111, flips=1
Increment 8: counter=1000, flips=4
Increment 9: counter=1001, flips=1
Increment 10: counter=1010, flips=2
Total flips = 18, amortized = 1.80  (bound: 2n = 20)
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int k,n; cin>>k>>n; vector<int> bits(k,0); int total=0;
    for(int t=1;t<=n;t++){
        int i=0,flips=0;
        while(i<k&&bits[i]==1){ bits[i]=0; flips++; i++; }
        if(i<k){ bits[i]=1; flips++; }
        total+=flips;
        string s; for(int x=k-1;x>=0;x--) s+=char('0'+bits[x]);
        printf("Increment %d: counter=%s, flips=%d\n",t,s.c_str(),flips);
    }
    printf("Total flips = %d, amortized = %.2f  (bound: 2n = %d)\n",total,(double)total/n,2*n);
}
