/*
QUESTION 12: Dynamic Tables (Amortized Analysis)

Scenario Description:
A dynamic array starts with capacity 1 and doubles when full (copying all elements). For M insertions, compute the actual cost of each insertion, the total cost and amortized cost per insertion.

Input Format:
• Line 1: M (number of insertions)

Output Format:
• Table size after each insertion with its cost
• Final line: total cost and amortized cost

Input:
10

Expected Output:
Insert 1: capacity=1, cost=1
Insert 2: capacity=2, cost=2
Insert 3: capacity=4, cost=3
Insert 4: capacity=4, cost=1
Insert 5: capacity=8, cost=5
Insert 6: capacity=8, cost=1
Insert 7: capacity=8, cost=1
Insert 8: capacity=8, cost=1
Insert 9: capacity=16, cost=9
Insert 10: capacity=16, cost=1
Total cost = 25, amortized = 2.50  (bounded by 3)
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int m; cin>>m; int size=0,cap=1,total=0;
    for(int i=1;i<=m;i++){
        int cost;
        if(size==cap){ cost=size+1; cap*=2; } else cost=1;
        size++; total+=cost;
        printf("Insert %d: capacity=%d, cost=%d\n",i,cap,cost);
    }
    printf("Total cost = %d, amortized = %.2f  (bounded by 3)\n",total,(double)total/m);
}
