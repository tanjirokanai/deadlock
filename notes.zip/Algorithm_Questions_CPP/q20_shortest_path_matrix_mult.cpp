/*
QUESTION 20: Shortest Paths and Matrix Multiplication

Scenario Description:
Compute all-pairs shortest paths using repeated squaring of the weight matrix with the (min,+) product, instead of Floyd-Warshall.

Input Format:
• Line 1: V E
• Next E lines: u v w

Output Format:
• Final V x V shortest path matrix and the number of squarings used

Input:
4 7
1 2 3
1 4 7
2 1 8
2 3 2
3 1 5
3 4 1
4 1 2

Expected Output:
Squarings used: 2
0 3 5 6
5 0 2 3
3 6 0 1
2 5 7 0
*/

#include <bits/stdc++.h>
using namespace std;

int V; const long long INF=1000000000LL;
typedef vector<vector<long long>> M;
M mul(const M&A,const M&B){
    M C(V,vector<long long>(V,LLONG_MAX));
    for(int i=0;i<V;i++) for(int j=0;j<V;j++) for(int k=0;k<V;k++)
        C[i][j]=min(C[i][j],A[i][k]+B[k][j]);
    return C;
}
int main(){
    int E; cin>>V>>E; M W(V,vector<long long>(V,INF));
    for(int i=0;i<V;i++) W[i][i]=0;
    for(int i=0;i<E;i++){ int u,v,w; cin>>u>>v>>w; W[u-1][v-1]=min(W[u-1][v-1],(long long)w); }
    M L=W; int m=1,sq=0;
    while(m<V-1){ L=mul(L,L); m*=2; sq++; }
    cout<<"Squarings used: "<<sq<<"\n";
    for(int i=0;i<V;i++){
        for(int j=0;j<V;j++){
            if(j) cout<<" ";
            if(L[i][j]>=INF) cout<<"INF"; else cout<<L[i][j];
        }
        cout<<"\n";
    }
}
