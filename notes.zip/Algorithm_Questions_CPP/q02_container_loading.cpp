/*
QUESTION 2: Container Loading Problem (Greedy)

Scenario Description:
A cargo ship can carry at most W tonnes. There are N containers of different weights. Load the maximum NUMBER of containers onto the ship.

Input Format:
• Line 1: W N
• Line 2: N container weights

Output Format:
• Line 1: Number of containers loaded
• Line 2: Weights of loaded containers

Input:
50 6
10 20 15 30 5 25

Expected Output:
Containers loaded: 4
Weights loaded: 5 10 15 20 (total = 50 )
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int W,n; cin>>W>>n;
    vector<int> w(n); for(auto&x:w) cin>>x;
    sort(w.begin(),w.end());
    int tot=0; vector<int> load;
    for(int x:w){ if(tot+x<=W){ tot+=x; load.push_back(x);} else break; }
    cout<<"Containers loaded: "<<load.size()<<"\n";
    cout<<"Weights loaded:";
    for(int x:load) cout<<" "<<x;
    cout<<" (total = "<<tot<<" )\n";
}
