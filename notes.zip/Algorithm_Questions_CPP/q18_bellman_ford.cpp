/*
QUESTION 18: The Bellman-Ford Algorithm

Scenario Description:
A currency/route network has directed edges that may have negative weights. Find shortest distances from a source, or report that a negative-weight cycle is reachable.

Input Format:
• Line 1: V E
• Next E lines: u v w (directed)
• Last line: source

Output Format:
• Distances, or the message: Negative cycle detected

Input:
5 10
1 2 6
1 4 7
2 3 5
2 4 8
2 5 -4
3 2 -2
4 3 -3
4 5 9
5 1 2
5 3 7
1

Expected Output:
dist[1] = 0
dist[2] = 2
dist[3] = 4
dist[4] = 7
dist[5] = -2
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int V,E; cin>>V>>E; vector<array<int,3>> ed(E);
    for(auto&e:ed) cin>>e[0]>>e[1]>>e[2];
    int s; cin>>s; const long long INF=LLONG_MAX/4;
    vector<long long> d(V+1,INF); d[s]=0;
    for(int i=0;i<V-1;i++)
        for(auto&e:ed) if(d[e[0]]<INF&&d[e[0]]+e[2]<d[e[1]]) d[e[1]]=d[e[0]]+e[2];
    for(auto&e:ed) if(d[e[0]]<INF&&d[e[0]]+e[2]<d[e[1]]){ cout<<"Negative cycle detected\n"; return 0; }
    for(int v=1;v<=V;v++){
        cout<<"dist["<<v<<"] = ";
        if(d[v]<INF) cout<<d[v]; else cout<<"INF";
        cout<<"\n";
    }
}
