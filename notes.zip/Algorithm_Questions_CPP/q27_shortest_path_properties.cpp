/*
QUESTION 27: Proofs of Shortest-Paths Properties - Distance Verifier

Scenario Description:
Given a directed graph, source and a claimed distance array d, verify using shortest-path properties: (1) d[source]=0, (2) triangle inequality d[v] <= d[u]+w holds on every edge, (3) every other reachable vertex has a tight edge (a predecessor with d[v]=d[u]+w).

Input Format:
• Line 1: V E
• Next E lines: u v w
• Next line: source
• Last line: V claimed distances

Output Format:
• VALID / INVALID with the violated property

Input:
5 6
1 2 10
1 3 3
3 2 4
3 4 2
2 4 1
4 5 6
1
0 7 3 5 11

Expected Output:
VALID shortest-path distances
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int V,E; cin>>V>>E; vector<array<int,3>> ed(E);
    for(auto&e:ed) cin>>e[0]>>e[1]>>e[2];
    int s; cin>>s; vector<long long> d(V+1,0);
    for(int i=1;i<=V;i++) cin>>d[i];
    if(d[s]!=0){ cout<<"INVALID: d[source] != 0\n"; return 0; }
    for(auto&e:ed) if(d[e[1]]>d[e[0]]+e[2]){
        cout<<"INVALID: triangle inequality violated on edge ("<<e[0]<<", "<<e[1]<<")\n"; return 0; }
    for(int v=1;v<=V;v++){
        if(v==s) continue; bool tight=false;
        for(auto&e:ed) if(e[1]==v&&d[e[0]]+e[2]==d[v]) tight=true;
        if(!tight){ cout<<"INVALID: no tight predecessor for vertex "<<v<<"\n"; return 0; }
    }
    cout<<"VALID shortest-path distances\n";
}
