/*
QUESTION 25: Graph Colouring (Backtracking)

Scenario Description:
Exam subjects (vertices) that share students (edges) need different time slots. Check whether the graph can be coloured with at most M colours and print one valid assignment.

Input Format:
• Line 1: V E M
• Next E lines: u v

Output Format:
• Line 1: Possible / Not possible
• Line 2: Colour of each vertex

Input:
5 7 3
1 2
1 3
2 3
2 4
3 4
3 5
4 5

Expected Output:
Possible
Colours: 1 2 3 1 2
*/

#include <bits/stdc++.h>
using namespace std;

int V,E,M; vector<vector<int>> g; vector<int> col;
bool bt(int v){
    if(v>V) return true;
    for(int c=1;c<=M;c++){
        bool good=true;
        for(int u:g[v]) if(col[u]==c){ good=false; break; }
        if(good){ col[v]=c; if(bt(v+1)) return true; col[v]=0; }
    }
    return false;
}
int main(){
    cin>>V>>E>>M; g.assign(V+1,{}); col.assign(V+1,0);
    for(int i=0;i<E;i++){ int u,v; cin>>u>>v; g[u].push_back(v); g[v].push_back(u); }
    if(bt(1)){
        cout<<"Possible\nColours:";
        for(int v=1;v<=V;v++) cout<<" "<<col[v];
        cout<<"\n";
    } else cout<<"Not possible\n";
}
