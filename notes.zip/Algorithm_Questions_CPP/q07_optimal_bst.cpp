/*
QUESTION 7: Optimal Binary Search Tree (Dynamic Programming)

Scenario Description:
A dictionary app stores N sorted keys with known search frequencies. Build a binary search tree with minimum total weighted search cost.

Input Format:
• Line 1: N
• Line 2: N frequencies (keys already in sorted order)

Output Format:
• Line 1: Minimum search cost
• Line 2: Root key of the optimal tree (1-based)

Input:
4
34 8 50 12

Expected Output:
Minimum cost: 166
Root key: 3
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin>>n;
    vector<long long> f(n+2,0),pre(n+2,0);
    for(int i=1;i<=n;i++){ cin>>f[i]; pre[i]=pre[i-1]+f[i]; }
    vector<vector<long long>> C(n+2,vector<long long>(n+2,0));
    vector<vector<int>> R(n+2,vector<int>(n+2,0));
    for(int i=1;i<=n;i++){ C[i][i]=f[i]; R[i][i]=i; }
    for(int len=2;len<=n;len++){
        for(int i=1;i<=n-len+1;i++){
            int j=i+len-1; C[i][j]=LLONG_MAX;
            for(int r=i;r<=j;r++){
                long long c=(r>i?C[i][r-1]:0)+(r<j?C[r+1][j]:0)+pre[j]-pre[i-1];
                if(c<C[i][j]){ C[i][j]=c; R[i][j]=r; }
            }
        }
    }
    cout<<"Minimum cost: "<<C[1][n]<<"\n";
    cout<<"Root key: "<<R[1][n]<<"\n";
}
