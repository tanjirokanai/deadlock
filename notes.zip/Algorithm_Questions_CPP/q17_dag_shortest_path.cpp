/*
QUESTION 17: Single-Source Shortest Paths in a DAG

Scenario Description:
A project has V tasks (nodes) with directed dependencies; edge weight is cost (can be negative). Using topological order, find the cheapest cost from the start task to every task.

Input Format:
• Line 1: V E
• Next E lines: u v w (directed)
• Last line: source

Output Format:
• Topological order, then shortest distance to each node

Input:
6 8
1 2 5
1 3 3
2 3 2
2 4 6
3 4 7
3 5 4
4 5 -1
5 6 -2
1

Expected Output:
Topological order: 1 2 3 4 5 6
dist[1] = 0
dist[2] = 5
dist[3] = 3
dist[4] = 10
dist[5] = 7
dist[6] = 5
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int V,E; cin>>V>>E; vector<vector<pair<int,int>>> g(V+1); vector<int> indeg(V+1,0);
    for(int i=0;i<E;i++){ int u,v,w; cin>>u>>v>>w; g[u].push_back({v,w}); indeg[v]++; }
    int s; cin>>s;
    queue<int> q; for(int i=1;i<=V;i++) if(indeg[i]==0) q.push(i);
    vector<int> order;
    while(!q.empty()){
        int u=q.front(); q.pop(); order.push_back(u);
        for(auto [v,w]:g[u]) if(--indeg[v]==0) q.push(v);
    }
    const long long INF=LLONG_MAX/4; vector<long long> d(V+1,INF); d[s]=0;
    for(int u:order) if(d[u]<INF) for(auto [v,w]:g[u]) d[v]=min(d[v],d[u]+w);
    cout<<"Topological order:";
    for(int u:order) cout<<" "<<u;
    cout<<"\n";
    for(int v=1;v<=V;v++){
        cout<<"dist["<<v<<"] = ";
        if(d[v]<INF) cout<<d[v]; else cout<<"INF";
        cout<<"\n";
    }
}
