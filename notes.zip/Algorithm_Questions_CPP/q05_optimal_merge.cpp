/*
QUESTION 5: Optimal Merge Pattern (Greedy)

Scenario Description:
A data centre must merge N sorted files into one. Merging two files of sizes a and b costs a+b. Find the minimum total merging cost.

Input Format:
• Line 1: N
• Line 2: N file sizes

Output Format:
• Line 1: Minimum total merge cost
• Next lines: each merge step

Input:
5
20 30 10 5 30

Expected Output:
Minimum merge cost: 205
Merge 5 + 10 = 15
Merge 15 + 20 = 35
Merge 30 + 30 = 60
Merge 35 + 60 = 95
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin>>n;
    priority_queue<long long,vector<long long>,greater<long long>> h;
    for(int i=0;i<n;i++){ long long x; cin>>x; h.push(x); }
    long long cost=0; vector<string> steps;
    while(h.size()>1){
        long long a=h.top(); h.pop(); long long b=h.top(); h.pop();
        cost+=a+b;
        steps.push_back("Merge "+to_string(a)+" + "+to_string(b)+" = "+to_string(a+b));
        h.push(a+b);
    }
    cout<<"Minimum merge cost: "<<cost<<"\n";
    for(auto&s:steps) cout<<s<<"\n";
}
