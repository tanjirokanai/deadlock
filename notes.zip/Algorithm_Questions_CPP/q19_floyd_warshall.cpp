/*
QUESTION 19: The Floyd-Warshall Algorithm

Scenario Description:
A metro authority wants the shortest travel cost between EVERY pair of V stations (directed routes).

Input Format:
• Line 1: V E
• Next E lines: u v w

Output Format:
• V x V matrix of shortest distances (INF if unreachable)

Input:
4 7
1 2 3
1 4 7
2 1 8
2 3 2
3 1 5
3 4 1
4 1 2

Expected Output:
0 3 5 6
5 0 2 3
3 6 0 1
2 5 7 0
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int V,E; cin>>V>>E; const long long INF=1000000000LL;
    vector<vector<long long>> d(V,vector<long long>(V,INF));
    for(int i=0;i<V;i++) d[i][i]=0;
    for(int i=0;i<E;i++){ int u,v,w; cin>>u>>v>>w; d[u-1][v-1]=min(d[u-1][v-1],(long long)w); }
    for(int k=0;k<V;k++) for(int i=0;i<V;i++) for(int j=0;j<V;j++)
        if(d[i][k]+d[k][j]<d[i][j]) d[i][j]=d[i][k]+d[k][j];
    for(int i=0;i<V;i++){
        for(int j=0;j<V;j++){
            if(j) cout<<" ";
            if(d[i][j]>=INF) cout<<"INF"; else cout<<d[i][j];
        }
        cout<<"\n";
    }
}
