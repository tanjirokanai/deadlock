/*
QUESTION 21: Approximation Algorithm for NP-Hard Problem - Vertex Cover

Scenario Description:
A city wants to place the fewest cameras at intersections (vertices) so every road (edge) is watched. Minimum vertex cover is NP-Hard, so use the 2-approximation algorithm.

Input Format:
• Line 1: V E
• Next E lines: u v

Output Format:
• Line 1: Cover vertices
• Line 2: Cover size (guaranteed at most 2 x optimal)

Input:
7 8
1 2
1 3
2 3
3 4
4 5
5 6
5 7
6 7

Expected Output:
Cover: 1 2 3 4 5 6
Cover size: 6
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int V,E; cin>>V>>E; set<int> cover;
    for(int i=0;i<E;i++){
        int u,v; cin>>u>>v;
        if(!cover.count(u)&&!cover.count(v)){ cover.insert(u); cover.insert(v); }
    }
    cout<<"Cover:";
    for(int x:cover) cout<<" "<<x;
    cout<<"\nCover size: "<<cover.size()<<"\n";
}
