/*
QUESTION 8: Longest Common Subsequence (Dynamic Programming)

Scenario Description:
A plagiarism checker compares two DNA/text sequences. Find the length of their longest common subsequence and one such subsequence.

Input Format:
• Line 1: String A
• Line 2: String B

Output Format:
• Line 1: LCS length
• Line 2: One LCS

Input:
ABCBDAB
BDCABA

Expected Output:
LCS length: 4
LCS: BCBA
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    string a,b; cin>>a>>b;
    int n=a.size(),m=b.size();
    vector<vector<int>> d(n+1,vector<int>(m+1,0));
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            d[i][j]=(a[i-1]==b[j-1])?d[i-1][j-1]+1:max(d[i-1][j],d[i][j-1]);
    int i=n,j=m; string s;
    while(i&&j){
        if(a[i-1]==b[j-1]){ s+=a[i-1]; i--; j--; }
        else if(d[i-1][j]>=d[i][j-1]) i--;
        else j--;
    }
    reverse(s.begin(),s.end());
    cout<<"LCS length: "<<d[n][m]<<"\n";
    cout<<"LCS: "<<s<<"\n";
}
