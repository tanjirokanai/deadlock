/*
QUESTION 4: Fractional Knapsack Problem (Greedy)

Scenario Description:
A trader can carry at most W kg of goods. There are N goods, each with a total value and weight, and goods can be divided into fractions. Maximise the value carried.

Input Format:
• Line 1: N W
• Next N lines: value weight

Output Format:
• Line 1: Maximum value (2 decimals)
• Next lines: fraction taken of each item used

Input:
3 50
60 10
100 20
120 30

Expected Output:
Maximum value: 240.00
Item 1: fraction 1.00
Item 2: fraction 1.00
Item 3: fraction 0.67
*/

#include <bits/stdc++.h>
using namespace std;

struct Item{ double r; int v,w,i; };
int main(){
    int n,W; cin>>n>>W; vector<Item> a;
    for(int i=0;i<n;i++){ int v,w; cin>>v>>w; a.push_back({(double)v/w,v,w,i+1}); }
    sort(a.begin(),a.end(),[](const Item&x,const Item&y){
        return make_tuple(x.r,x.v,x.w,x.i)>make_tuple(y.r,y.v,y.w,y.i); });
    double tot=0; vector<string> out;
    for(auto&t:a){
        if(W==0) break;
        int q=min(t.w,W); tot+=t.r*q; W-=q;
        char buf[64]; sprintf(buf,"Item %d: fraction %.2f",t.i,(double)q/t.w);
        out.push_back(buf);
    }
    printf("Maximum value: %.2f\n",tot);
    for(auto&s:out) puts(s.c_str());
}
