/*
QUESTION 14: Accounting Method - Stack with MULTIPOP

Scenario Description:
A stack supports PUSH x, POP and MULTIPOP k (pop up to k items). Charge amortized cost 2 for PUSH, 0 for POP and 0 for MULTIPOP. Simulate operations, show actual cost and the credit balance after each.

Input Format:
• Line 1: M
• Next M lines: PUSH x | POP | MULTIPOP k

Output Format:
• For each operation: actual cost, amortized charge, credit
• Final line: totals

Input:
7
PUSH 1
PUSH 2
PUSH 3
MULTIPOP 2
PUSH 4
POP
MULTIPOP 5

Expected Output:
PUSH 1: actual=1, charged=2, credit=1
PUSH 2: actual=1, charged=2, credit=2
PUSH 3: actual=1, charged=2, credit=3
MULTIPOP 2: actual=2, charged=0, credit=1
PUSH 4: actual=1, charged=2, credit=2
POP: actual=1, charged=0, credit=1
MULTIPOP 5: actual=1, charged=0, credit=0
Total actual=8, total amortized=8, credit never negative: True
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int m; cin>>m; vector<int> st; int credit=0,ta=0,tc=0;
    for(int q=0;q<m;q++){
        string op; cin>>op; string desc=op; int actual,charge;
        if(op=="PUSH"){ int x; cin>>x; st.push_back(x); actual=1; charge=2; desc+=" "+to_string(x); }
        else if(op=="POP"){ actual=st.empty()?0:1; if(!st.empty()) st.pop_back(); charge=0; }
        else { int k; cin>>k; desc+=" "+to_string(k); k=min<int>(k,st.size()); st.resize(st.size()-k); actual=k; charge=0; }
        credit+=charge-actual; ta+=actual; tc+=charge;
        printf("%s: actual=%d, charged=%d, credit=%d\n",desc.c_str(),actual,charge,credit);
    }
    printf("Total actual=%d, total amortized=%d, credit never negative: %s\n",ta,tc,credit>=0?"True":"False");
}
