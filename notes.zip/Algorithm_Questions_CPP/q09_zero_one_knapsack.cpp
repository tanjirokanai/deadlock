/*
QUESTION 9: 0/1 Knapsack Problem (Dynamic Programming)

Scenario Description:
A courier van has capacity W. There are N parcels, each with a profit and weight, and each parcel must be taken whole or left. Maximise profit.

Input Format:
• Line 1: N W
• Next N lines: profit weight

Output Format:
• Line 1: Maximum profit
• Line 2: Selected parcels (1-based)

Input:
4 8
10 5
40 4
30 6
50 3

Expected Output:
Maximum profit: 90
Selected parcels: 2 4
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n,W; cin>>n>>W;
    vector<int> v(n+1),w(n+1);
    for(int i=1;i<=n;i++) cin>>v[i]>>w[i];
    vector<vector<int>> d(n+1,vector<int>(W+1,0));
    for(int i=1;i<=n;i++)
        for(int c=0;c<=W;c++){
            d[i][c]=d[i-1][c];
            if(w[i]<=c) d[i][c]=max(d[i][c],d[i-1][c-w[i]]+v[i]);
        }
    int c=W; vector<int> sel;
    for(int i=n;i>=1;i--)
        if(d[i][c]!=d[i-1][c]){ sel.push_back(i); c-=w[i]; }
    sort(sel.begin(),sel.end());
    cout<<"Maximum profit: "<<d[n][W]<<"\n";
    cout<<"Selected parcels:";
    for(int x:sel) cout<<" "<<x;
    cout<<"\n";
}
