/*
QUESTION 15: Potential Method - Binary Counter

Scenario Description:
Use the potential function Phi = (number of 1 bits) for a binary counter that is incremented N times. For each increment print actual cost, change in potential and amortized cost.

Input Format:
• Line 1: N

Output Format:
• For each increment: actual cost, delta Phi, amortized cost (= actual + delta Phi)

Input:
8

Expected Output:
Inc 1: actual=1, deltaPhi=1, amortized=2
Inc 2: actual=2, deltaPhi=0, amortized=2
Inc 3: actual=1, deltaPhi=1, amortized=2
Inc 4: actual=3, deltaPhi=-1, amortized=2
Inc 5: actual=1, deltaPhi=1, amortized=2
Inc 6: actual=2, deltaPhi=0, amortized=2
Inc 7: actual=1, deltaPhi=1, amortized=2
Inc 8: actual=4, deltaPhi=-2, amortized=2
*/

#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin>>n; int x=0;
    for(int t=1;t<=n;t++){
        int prev=__builtin_popcount(x), t0=0, y=x;
        while(y&1){ t0++; y>>=1; }
        x++; int cost=t0+1; int phi=__builtin_popcount(x);
        printf("Inc %d: actual=%d, deltaPhi=%d, amortized=%d\n",t,cost,phi-prev,cost+phi-prev);
    }
}
