/*
QUESTION 24: N-Queens Problem (Backtracking)

Scenario Description:
Place N queens on an N x N chessboard so that no two attack each other. Count all solutions and print the first.

Input Format:
• Line 1: N

Output Format:
• Line 1: Number of solutions
• Then the first solution as a board (Q = queen, . = empty)

Input:
6

Expected Output:
Number of solutions: 4
.Q....
...Q..
.....Q
Q.....
..Q...
....Q.
*/

#include <bits/stdc++.h>
using namespace std;

int n; vector<int> cols; vector<vector<int>> sols;
bool ok(int r,int c){
    for(int rr=0;rr<(int)cols.size();rr++)
        if(c==cols[rr]||abs(c-cols[rr])==r-rr) return false;
    return true;
}
void bt(int r){
    if(r==n){ sols.push_back(cols); return; }
    for(int c=0;c<n;c++) if(ok(r,c)){ cols.push_back(c); bt(r+1); cols.pop_back(); }
}
int main(){
    cin>>n; bt(0);
    cout<<"Number of solutions: "<<sols.size()<<"\n";
    if(!sols.empty())
        for(int c:sols[0]){
            for(int j=0;j<n;j++) cout<<(j==c?'Q':'.');
            cout<<"\n";
        }
}
