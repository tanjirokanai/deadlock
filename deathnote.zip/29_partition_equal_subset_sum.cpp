/*
================================================================================
Topic: Partition Equal Subset Sum
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
A dual-core compute cluster receives N batch tasks with execution times T[1...N]. Determine whether 
the tasks can be partitioned into two subsets with identical total run times so both cores finish concurrently.

Input Format:
Line 1: An integer N (number of tasks).
Line 2: N space-separated integers representing task durations.

Output Format:
Line 1: Status message ("Possible to partition into two equal subsets." or "Cannot be partitioned.").
Line 2: Target duration per core if possible.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4
1 5 11 5

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Possible to partition into two equal subsets.
Target duration per core: 11
================================================================================
*/

#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<int> nums(n);
    int total_sum = 0;
    for (int i = 0; i < n; i++) {
        cin >> nums[i];
        total_sum += nums[i];
    }

    if (total_sum % 2 != 0) {
        cout << "Cannot be partitioned into two equal subsets.\n";
        return 0;
    }

    int target = total_sum / 2;
    vector<bool> dp(target + 1, false);
    dp[0] = true;

    for (int x : nums) {
        for (int j = target; j >= x; j--) {
            if (dp[j - x]) dp[j] = true;
        }
    }

    if (dp[target]) {
        cout << "Possible to partition into two equal subsets.\n";
        cout << "Target duration per core: " << target << "\n";
    } else {
        cout << "Cannot be partitioned into two equal subsets.\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. If sum(nums) is odd, partition into two equal integer halves is impossible.
2. Target = sum(nums) / 2. Problem reduces to finding if any subset sums to Target (Subset Sum Problem).
3. 1D DP boolean array: dp[j] represents if a subset sum of j is achievable.
4. Iterate backwards from Target down to x for each number x to ensure each item is used at most once (0/1 constraint).

Edge Cases:
- Total sum is odd: Return false immediately in O(1).
- Single element: Cannot be split into two non-empty subsets unless target = 0.
- Elements with value > Target: Naturally ignored by inner loop condition j >= x.

Complexity Analysis:
- Time Complexity: O(N * Target) = O(N * Sum).
- Space Complexity: O(Target) = O(Sum / 2).
================================================================================
*/
