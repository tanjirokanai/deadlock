/*
================================================================================
Topic: 0/1 Knapsack Problem
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
A bank vault security system enforces a total loot bag capacity limit of W kg. A burglar identifies 
N distinct gold bars and jewelry sets. Each item i has integer weight wt[i] and market value val[i], and cannot be divided. 
Determine the maximum attainable value and list the selected items.

Input Format:
Line 1: Two integers N and W (number of items and capacity).
Line 2: N space-separated integers representing values.
Line 3: N space-separated integers representing weights.

Output Format:
Line 1: Maximum value in Knapsack.
Line 2: Selected 1-indexed item indices.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4 8
10 40 30 50
1 3 4 5

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Maximum value in Knapsack: 90
Selected item indices: 2 4
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n, W;
    if (!(cin >> n >> W)) return 0;

    vector<int> val(n + 1), wt(n + 1);
    for (int i = 1; i <= n; i++) cin >> val[i];
    for (int i = 1; i <= n; i++) cin >> wt[i];

    vector<vector<int>> dp(n + 1, vector<int>(W + 1, 0));

    for (int i = 1; i <= n; i++) {
        for (int w = 0; w <= W; w++) {
            if (wt[i] <= w) {
                dp[i][w] = max(dp[i - 1][w], val[i] + dp[i - 1][w - wt[i]]);
            } else {
                dp[i][w] = dp[i - 1][w];
            }
        }
    }

    cout << "Maximum value in Knapsack: " << dp[n][W] << "\n";

    int res = dp[n][W];
    int w = W;
    vector<int> selected;
    for (int i = n; i > 0 && res > 0; i--) {
        if (res != dp[i - 1][w]) {
            selected.push_back(i);
            res -= val[i];
            w -= wt[i];
        }
    }
    reverse(selected.begin(), selected.end());

    cout << "Selected item indices: ";
    for (size_t i = 0; i < selected.size(); i++) {
        cout << selected[i] << (i + 1 == selected.size() ? "" : " ");
    }
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Subproblem definition: dp[i][w] represents max value achievable using a subset of first i items with weight limit w.
2. State recurrence:
   dp[i][w] = dp[i-1][w]                                    if wt[i] > w
   dp[i][w] = max(dp[i-1][w], val[i] + dp[i-1][w - wt[i]])  if wt[i] <= w
3. Base cases: dp[0][w] = 0 for all w; dp[i][0] = 0 for all i.
4. Backtracking: Compare dp[i][w] with dp[i-1][w]; if different, item i was selected.

Edge Cases:
- W = 0 or N = 0: Max profit = 0.
- All items wt[i] > W: Max profit = 0, no items selected.
- Capacity W is very large: Dynamic programming is pseudo-polynomial in W.

Complexity Analysis:
- Time Complexity: O(N * W).
- Space Complexity: O(N * W) for 2D DP matrix (can be optimized to O(W) with 1D array if item reconstruction is not required).
================================================================================
*/
