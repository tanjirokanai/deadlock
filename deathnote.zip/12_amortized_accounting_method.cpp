/*
================================================================================
Topic: The Accounting Method (Amortized Analysis)
Module / Unit: Amortized Analysis
================================================================================
Scenario Description:
A scalable distributed memory buffer doubles its table capacity whenever full. Using the Accounting 
Method, assign an amortized charge of 3 credits to each simple insertion (1 for immediate write, 2 saved as bank credit) 
to fully pay for future O(N) table copying without dipping into deficit.

Input Format:
Line 1: An integer N (number of successive table insertions).

Output Format:
N lines: After each insert: Element ID, Current Size, Capacity, Actual Cost, Amortized Charge, Bank Credit.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
6

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Insert 1: Size=1, Cap=1, Actual=1, Charge=3, BankCredit=2
Insert 2: Size=2, Cap=2, Actual=2, Charge=3, BankCredit=3
Insert 3: Size=3, Cap=4, Actual=3, Charge=3, BankCredit=3
Insert 4: Size=4, Cap=4, Actual=1, Charge=3, BankCredit=5
Insert 5: Size=5, Cap=8, Actual=5, Charge=3, BankCredit=3
Insert 6: Size=6, Cap=8, Actual=1, Charge=3, BankCredit=5
================================================================================
*/

#include <iostream>

using namespace std;

int main() {
    int n;
    if (!(cin >> n)) return 0;

    int capacity = 1;
    int size = 0;
    long long bank_credit = 0;
    const int amortized_charge = 3;

    for (int i = 1; i <= n; i++) {
        int actual_cost = 1;
        if (size == capacity) {
            actual_cost = size + 1; // 1 for new insert + size for copying old elements
            capacity *= 2;
        }
        size++;
        bank_credit += (amortized_charge - actual_cost);

        cout << "Insert " << i << ": "
             << "Size=" << size << ", "
             << "Cap=" << capacity << ", "
             << "Actual=" << actual_cost << ", "
             << "Charge=" << amortized_charge << ", "
             << "BankCredit=" << bank_credit << "\n";
    }
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. In the Accounting Method, different operations are assigned an amortized charge c'_i.
2. When c'_i > c_i (actual cost), surplus is stored as credit in an account.
3. For table doubling:
   - 1 credit pays for current insertion.
   - 1 credit pays for copying this element when table doubles.
   - 1 credit pays for copying an older element that has already exhausted its credit.
4. Total credit balance never drops below zero: sum(c'_i) >= sum(c_i), ensuring valid upper bound.

Edge Cases:
- Table never resizes (N = 1): Credit bank strictly positive.
- Exactly power-of-2 insertions (N = 2, 4, 8): Credit bank hits minimum safe threshold right after expansion.

Complexity Analysis:
- Time Complexity: Amortized O(1) per insertion; Total time O(N) for N inserts.
- Space Complexity: O(1) auxiliary variables.
================================================================================
*/
