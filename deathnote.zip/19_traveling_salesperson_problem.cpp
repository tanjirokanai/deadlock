/*
================================================================================
Topic: Traveling Salesperson Problem (TSP)
Module / Unit: Backtracking
================================================================================
Scenario Description:
A field logistics inspector must visit N branch offices starting from office 1, visiting every 
office exactly once, and returning to office 1. Given the distance matrix, find the tour with minimum total travel cost.

Input Format:
Line 1: An integer N (number of cities).
Next N lines: N x N distance matrix.

Output Format:
Line 1: Minimum TSP tour cost.
Line 2: Optimal tour route sequence.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4
0 10 15 20
10 0 35 25
15 35 0 30
20 25 30 0

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Minimum TSP tour cost: 80
Optimal tour sequence: 1 -> 2 -> 4 -> 3 -> 1
================================================================================
*/

#include <iostream>
#include <vector>
#include <climits>

using namespace std;

int n;
vector<vector<int>> dist;
vector<bool> visited;
int min_cost = INT_MAX;
vector<int> best_path;
vector<int> curr_path;

void tsp(int curr, int count, int cost) {
    if (cost >= min_cost) return; // Pruning / Bounding

    if (count == n && dist[curr][0] > 0) {
        if (cost + dist[curr][0] < min_cost) {
            min_cost = cost + dist[curr][0];
            best_path = curr_path;
            best_path.push_back(1);
        }
        return;
    }

    for (int nxt = 0; nxt < n; nxt++) {
        if (!visited[nxt] && dist[curr][nxt] > 0) {
            visited[nxt] = true;
            curr_path.push_back(nxt + 1);
            tsp(nxt, count + 1, cost + dist[curr][nxt]);
            curr_path.pop_back();
            visited[nxt] = false;
        }
    }
}

int main() {
    if (!(cin >> n)) return 0;

    dist.assign(n, vector<int>(n));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) cin >> dist[i][j];
    }

    visited.assign(n, false);
    visited[0] = true;
    curr_path.push_back(1);

    tsp(0, 1, 0);

    cout << "Minimum TSP tour cost: " << min_cost << "\n";
    cout << "Optimal tour sequence: ";
    for (size_t i = 0; i < best_path.size(); i++) {
        cout << best_path[i] << (i + 1 == best_path.size() ? "" : " -> ");
    }
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Explores permutation tree using Depth-First Search with backtracking.
2. Maintain visited array to ensure each vertex is visited exactly once.
3. Bounding/Pruning: If partial path cost >= current best min_cost, prune entire subtree.
4. When all N vertices are visited, add return edge to start vertex and update best tour.

Edge Cases:
- Disconnected cities (dist[u][v] = 0 or INF): Checked before branching.
- Small N (N <= 3): Solved almost instantaneously.
- Asymmetric distances: Naturally handled by directed distance matrix.

Complexity Analysis:
- Time Complexity: O((N-1)!) worst-case permutation search; pruning significantly reduces practical running time.
- Space Complexity: O(N) for recursion stack and path history.
================================================================================
*/
