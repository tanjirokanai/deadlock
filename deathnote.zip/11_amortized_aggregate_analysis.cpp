/*
================================================================================
Topic: Aggregate Analysis (Amortized Analysis)
Module / Unit: Amortized Analysis
================================================================================
Scenario Description:
A transaction processor operates a stack data structure supporting PUSH, POP, and MULTIPOP(k). 
While an individual MULTIPOP operation takes up to O(k) time, apply Aggregate Analysis across N operations to prove 
the average cost per operation is O(1).

Input Format:
Line 1: An integer N (number of operations).
Next N lines: Operation string (PUSH <val>, POP, or MULTIPOP <k>).

Output Format:
Line 1: Total actual operations cost.
Line 2: Amortized cost per operation.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
7
PUSH 10
PUSH 20
MULTIPOP 2
PUSH 30
PUSH 40
POP
PUSH 50

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Total actual operations cost: 7
Amortized cost per operation: 1.00
================================================================================
*/

#include <iostream>
#include <vector>
#include <string>
#include <stack>
#include <iomanip>

using namespace std;

int main() {
    int n;
    if (!(cin >> n)) return 0;

    stack<int> s;
    long long total_actual_cost = 0;

    for (int i = 0; i < n; i++) {
        string op;
        cin >> op;
        if (op == "PUSH") {
            int val;
            cin >> val;
            s.push(val);
            total_actual_cost += 1;
        } else if (op == "POP") {
            if (!s.empty()) {
                s.pop();
                total_actual_cost += 1;
            }
        } else if (op == "MULTIPOP") {
            int k;
            cin >> k;
            int popped = 0;
            while (!s.empty() && popped < k) {
                s.pop();
                popped++;
                total_actual_cost += 1;
            }
        }
    }

    cout << "Total actual operations cost: " << total_actual_cost << "\n";
    cout << fixed << setprecision(2);
    cout << "Amortized cost per operation: " << (double)total_actual_cost / n << "\n";
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. In aggregate analysis, we evaluate the worst-case total cost T(N) for an entire sequence of N operations.
2. The amortized cost per operation is defined as T(N) / N.
3. An element can be popped at most once for each time it is pushed.
4. Number of POP/MULTIPOP operations <= Number of PUSH operations <= N.
5. Therefore, Total Cost <= 2N, giving an amortized cost of O(1) per operation.

Edge Cases:
- All operations are PUSH: Total cost = N, amortized cost = 1.
- All operations are MULTIPOP on empty stack: Cost = 0.
- Single massive MULTIPOP after N-1 pushes: Takes O(N) time individually, but amortized sequence is O(1).

Complexity Analysis:
- Time Complexity: O(N) aggregate across all N operations.
- Space Complexity: O(N) to store stack elements.
================================================================================
*/
