/*
================================================================================
Topic: Kruskal's Algorithm using Disjoint Set Union
Module / Unit: Greedy Technique
================================================================================
Scenario Description:
An internet backbone operator wants to connect N core optical routers. Given installation costs 
for candidate fiber connections, design the minimum cost tree using Kruskal's algorithm with Disjoint Set Union (DSU).

Input Format:
Line 1: Two integers N and E (routers and candidate fiber links).
Next E lines: Three integers u, v, w representing undirected link between u and v with cost w.

Output Format:
Line 1: Total Minimum Backbone Installation Cost.
Next lines: Chosen fiber links.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4 5
1 2 10
1 3 6
1 4 5
2 4 15
3 4 4

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Total Minimum Backbone Installation Cost: 19
Chosen Fiber Links:
Link 3 - 4 (Cost: 4)
Link 1 - 4 (Cost: 5)
Link 1 - 2 (Cost: 10)
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Edge {
    int u, v, w;
};

bool compareEdge(const Edge& a, const Edge& b) {
    return a.w < b.w;
}

struct DSU {
    vector<int> parent, rank;
    DSU(int n) {
        parent.resize(n + 1);
        rank.assign(n + 1, 0);
        for (int i = 0; i <= n; i++) parent[i] = i;
    }
    int find(int i) {
        if (parent[i] == i) return i;
        return parent[i] = find(parent[i]);
    }
    bool unite(int i, int j) {
        int root_i = find(i);
        int root_j = find(j);
        if (root_i != root_j) {
            if (rank[root_i] < rank[root_j]) swap(root_i, root_j);
            parent[root_j] = root_i;
            if (rank[root_i] == rank[root_j]) rank[root_i]++;
            return true;
        }
        return false;
    }
};

int main() {
    int n, e;
    if (!(cin >> n >> e)) return 0;

    vector<Edge> edges(e);
    for (int i = 0; i < e; i++) {
        cin >> edges[i].u >> edges[i].v >> edges[i].w;
    }

    sort(edges.begin(), edges.end(), compareEdge);

    DSU dsu(n);
    long long total_cost = 0;
    vector<Edge> mst;

    for (const auto& edge : edges) {
        if (dsu.unite(edge.u, edge.v)) {
            total_cost += edge.w;
            mst.push_back(edge);
        }
    }

    cout << "Total Minimum Backbone Installation Cost: " << total_cost << "\n";
    cout << "Chosen Fiber Links:\n";
    for (const auto& edge : mst) {
        cout << "Link " << edge.u << " - " << edge.v << " (Cost: " << edge.w << ")\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Sort all E edges in non-decreasing order of weight.
2. Initialize Disjoint Set Union (DSU) where each vertex is in its own isolated set.
3. For each edge (u, v):
   - If find(u) != find(v): The edge connects two separate components without forming a cycle.
   - Add edge to MST and call unite(u, v).
   - If find(u) == find(v): Discard edge (would create a cycle).
4. Terminate when (N - 1) edges are selected or edge list is exhausted.

Edge Cases:
- Disconnected graph: MST will have fewer than N - 1 edges.
- Graph with identical edge weights: Any tie-breaking produces a valid MST.

Complexity Analysis:
- Time Complexity: O(E log E) for sorting edges + O(E * alpha(V)) for DSU operations = O(E log E).
- Space Complexity: O(V + E) for edge list and DSU parent/rank arrays.
================================================================================
*/
