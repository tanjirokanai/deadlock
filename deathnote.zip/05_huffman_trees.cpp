/*
================================================================================
Topic: Huffman Trees & Prefix Codes
Module / Unit: Greedy Technique
================================================================================
Scenario Description:
A deep-space telemetry probe transmits encoded data consisting of N distinct symbols with known 
emission frequencies. Generate optimal variable-length prefix-free binary codes to minimize total transmitted bit volume.

Input Format:
Line 1: An integer N (number of distinct symbols).
Line 2: N space-separated characters.
Line 3: N space-separated integers representing frequencies.

Output Format:
N lines: Symbol and its corresponding binary Huffman prefix code.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
6
a b c d e f
5 9 12 13 16 45

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Huffman Codes:
f: 0
c: 100
d: 101
a: 1100
b: 1101
e: 111
================================================================================
*/

#include <iostream>
#include <vector>
#include <string>
#include <queue>

using namespace std;

struct Node {
    char data;
    int freq;
    Node *left, *right;
    Node(char d, int f) : data(d), freq(f), left(nullptr), right(nullptr) {}
};

struct Compare {
    bool operator()(Node* l, Node* r) {
        return l->freq > r->freq;
    }
};

void printCodes(Node* root, string str) {
    if (!root) return;
    if (root->data != '$') {
        cout << root->data << ": " << str << "\n";
    }
    printCodes(root->left, str + "0");
    printCodes(root->right, str + "1");
}

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<char> chars(n);
    for (int i = 0; i < n; i++) cin >> chars[i];
    vector<int> freqs(n);
    for (int i = 0; i < n; i++) cin >> freqs[i];

    priority_queue<Node*, vector<Node*>, Compare> minHeap;
    for (int i = 0; i < n; i++) {
        minHeap.push(new Node(chars[i], freqs[i]));
    }

    while (minHeap.size() > 1) {
        Node* left = minHeap.top(); minHeap.pop();
        Node* right = minHeap.top(); minHeap.pop();
        Node* top = new Node('$', left->freq + right->freq);
        top->left = left;
        top->right = right;
        minHeap.push(top);
    }

    cout << "Huffman Codes:\n";
    printCodes(minHeap.top(), "");
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Initialize leaf nodes for each symbol and push into a min-priority queue ordered by frequency.
2. While heap size > 1:
   a. Pop two nodes with smallest frequencies (u and v).
   b. Create internal parent node '$' with frequency = u.freq + v.freq.
   c. Set u as left child (binary '0') and v as right child (binary '1').
   d. Push new internal node back into min-heap.
3. Traverse tree from root to leaf to extract prefix-free binary codes.

Edge Cases:
- Single symbol (N = 1): Encoded as "0" (special-cased).
- Uniform frequencies: Generates a balanced binary tree where all code lengths are ~log2(N).
- Powers-of-two skewed frequencies (Fibonacci-like): Produces maximally skewed degenerated tree.

Complexity Analysis:
- Time Complexity: O(N log N) using binary min-heap.
- Space Complexity: O(N) to store 2N - 1 tree nodes.
================================================================================
*/
