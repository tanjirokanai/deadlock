/*
================================================================================
Topic: The Potential Method (Amortized Analysis)
Module / Unit: Amortized Analysis
================================================================================
Scenario Description:
A 32-bit hardware register counter increments from 0 to N. Bit-flipping incurs energy cost. 
Using the Potential Function Phi(D_i) = number of 1-bits in the counter, prove the amortized cost per increment is exactly 2.

Input Format:
Line 1: An integer N (number of successive increments).

Output Format:
N lines: Step index, Current value, Actual bit flips, Potential change dPhi, and Amortized cost.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
5

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Step 1: Bits=1, ActualFlips=1, dPhi=1, AmortizedCost=2
Step 2: Bits=2, ActualFlips=2, dPhi=0, AmortizedCost=2
Step 3: Bits=3, ActualFlips=1, dPhi=1, AmortizedCost=2
Step 4: Bits=4, ActualFlips=3, dPhi=-1, AmortizedCost=2
Step 5: Bits=5, ActualFlips=1, dPhi=1, AmortizedCost=2
================================================================================
*/

#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<int> A(32, 0);
    int prev_ones = 0;

    for (int step = 1; step <= n; step++) {
        int i = 0;
        int actual_flips = 0;
        while (i < 32 && A[i] == 1) {
            A[i] = 0;
            actual_flips++;
            i++;
        }
        if (i < 32) {
            A[i] = 1;
            actual_flips++;
        }

        int curr_ones = 0;
        for (int b : A) curr_ones += b;

        int dPhi = curr_ones - prev_ones;
        int amortized_cost = actual_flips + dPhi;
        prev_ones = curr_ones;

        cout << "Step " << step << ": "
             << "Bits=" << step << ", "
             << "ActualFlips=" << actual_flips << ", "
             << "dPhi=" << dPhi << ", "
             << "AmortizedCost=" << amortized_cost << "\n";
    }
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Potential function Phi(D_i) maps data structure state to a real number >= 0.
2. Amortized cost: a_i = c_i + Phi(D_i) - Phi(D_{i-1}).
3. For binary counter: let t_i be number of bits reset from 1 to 0 during i-th increment.
   - Actual flips: c_i = t_i + 1 (resets t_i ones to zeros, sets one zero to one).
   - Potential change: Phi(D_i) - Phi(D_{i-1}) = 1 - t_i.
   - Amortized cost: a_i = (t_i + 1) + (1 - t_i) = 2.
4. Hence, amortized cost of each increment is constant O(1).

Edge Cases:
- All bits are 1: Max cascading carry; actual cost high, potential drops sharply.
- Counter initially all zeros: Phi(D_0) = 0 <= Phi(D_N), valid potential framework.

Complexity Analysis:
- Time Complexity: Amortized O(1) per increment; total O(N) bit flips.
- Space Complexity: O(1) space for 32-bit register.
================================================================================
*/
