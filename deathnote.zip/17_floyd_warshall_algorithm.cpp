/*
================================================================================
Topic: The Floyd-Warshall Algorithm (APSP)
Module / Unit: Graph Algorithms
================================================================================
Scenario Description:
A national rail transport system requires an all-pairs transit duration matrix across V major 
junction stations. Compute the shortest path between every pair of vertices using dynamic programming.

Input Format:
Line 1: Two integers V and E (stations and direct rail segments).
Next E lines: Three integers u, v, w representing directed rail segment with travel time w.

Output Format:
V lines: V space-separated shortest durations (INF for unreachable pairs).

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4 4
1 2 3
2 3 1
1 4 7
3 4 2

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
All-Pairs Shortest Path Matrix:
0 3 4 6
INF 0 1 3
INF INF 0 2
INF INF INF 0
================================================================================
*/

#include <iostream>
#include <vector>

using namespace std;

const long long INF = 1e18;

int main() {
    int v, e;
    if (!(cin >> v >> e)) return 0;

    vector<vector<long long>> dist(v + 1, vector<long long>(v + 1, INF));

    for (int i = 1; i <= v; i++) dist[i][i] = 0;

    for (int i = 0; i < e; i++) {
        int u, to;
        long long w;
        cin >> u >> to >> w;
        dist[u][to] = min(dist[u][to], w);
    }

    for (int k = 1; k <= v; k++) {
        for (int i = 1; i <= v; i++) {
            for (int j = 1; j <= v; j++) {
                if (dist[i][k] != INF && dist[k][j] != INF) {
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
    }

    cout << "All-Pairs Shortest Path Matrix:\n";
    for (int i = 1; i <= v; i++) {
        for (int j = 1; j <= v; j++) {
            if (dist[i][j] == INF) cout << "INF";
            else cout << dist[i][j];
            cout << (j == v ? "" : " ");
        }
        cout << "\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Let dist[i][j]^(k) be shortest path length from i to j using intermediate vertices from {1, 2, ..., k}.
2. Recurrence:
   dist[i][j]^(k) = min(dist[i][j]^(k-1), dist[i][k]^(k-1) + dist[k][j]^(k-1)).
3. Iterate k from 1 to V, updating table in place.
4. Detects negative cycles if dist[i][i] becomes negative for any vertex i.

Edge Cases:
- Disconnected pairs: Retain INF.
- Negative cycles: Diagnosed if dist[i][i] < 0.
- Parallel edges: Take minimum weight at initialization.

Complexity Analysis:
- Time Complexity: O(V^3) via 3 nested loops.
- Space Complexity: O(V^2) for distance matrix.
================================================================================
*/
