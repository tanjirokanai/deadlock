/*
================================================================================
Topic: Hamiltonian Cycle Problem
Module / Unit: Backtracking
================================================================================
Scenario Description:
A robotic inspection vehicle must patrol an industrial facility of V checkpoints. It must start 
at checkpoint 1, visit every checkpoint exactly once, and return to checkpoint 1 along valid floor tracks. 
Find a valid Hamiltonian Cycle.

Input Format:
Line 1: Two integers V and E (checkpoints and valid tracks).
Next E lines: Two integers u and v representing an undirected track between u and v.

Output Format:
Line 1: Status message ("Hamiltonian Cycle found:" or "No Hamiltonian Cycle exists.").
Line 2: Sequence of checkpoints in the cycle.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
5 7
1 2
1 4
2 3
2 4
2 5
3 5
4 5

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Hamiltonian Cycle found:
1 -> 2 -> 3 -> 5 -> 4 -> 1
================================================================================
*/

#include <iostream>
#include <vector>

using namespace std;

int v, e;
vector<vector<bool>> graph;
vector<int> path;

bool isSafe(int node, int pos) {
    if (!graph[path[pos - 1]][node]) return false;

    for (int i = 0; i < pos; i++) {
        if (path[i] == node) return false;
    }
    return true;
}

bool hamCycleUtil(int pos) {
    if (pos == v) {
        return graph[path[pos - 1]][path[0]];
    }

    for (int next_node = 2; next_node <= v; next_node++) {
        if (isSafe(next_node, pos)) {
            path[pos] = next_node;
            if (hamCycleUtil(pos + 1)) return true;
            path[pos] = -1; // Backtrack
        }
    }
    return false;
}

int main() {
    if (!(cin >> v >> e)) return 0;

    graph.assign(v + 1, vector<bool>(v + 1, false));
    for (int i = 0; i < e; i++) {
        int u, to;
        cin >> u >> to;
        graph[u][to] = true;
        graph[to][u] = true;
    }

    path.assign(v, -1);
    path[0] = 1;

    if (hamCycleUtil(1)) {
        cout << "Hamiltonian Cycle found:\n";
        for (int i = 0; i < v; i++) {
            cout << path[i] << " -> ";
        }
        cout << path[0] << "\n";
    } else {
        cout << "No Hamiltonian Cycle exists.\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Fix vertex 1 as starting point (path[0] = 1).
2. Recursively assign vertices to path positions pos = 1 to V - 1.
3. Check safety: candidate vertex must have an edge from path[pos - 1] and must not already appear in the path.
4. When pos == V, verify edge exists from path[V - 1] back to path[0].
5. If no valid neighbor leads to a cycle, backtrack and try next candidate.

Edge Cases:
- Complete Graph K_n: (n-1)! / 2 cycles exist.
- Bipartite graph with odd vertices: No Hamiltonian cycle possible.
- Degree of any vertex < 2: No Hamiltonian cycle exists (can prune early).

Complexity Analysis:
- Time Complexity: O(N!) worst-case.
- Space Complexity: O(V^2) graph matrix and O(V) path array.
================================================================================
*/
