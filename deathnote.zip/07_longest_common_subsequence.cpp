/*
================================================================================
Topic: Longest Common Subsequence (LCS)
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
A computational genetics research lab analyzes two DNA strands represented by uppercase character 
strings S1 and S2. Calculate the length of their longest conserved genetic subsequence and reconstruct the aligned sequence.

Input Format:
Line 1: String S1.
Line 2: String S2.

Output Format:
Line 1: Length of LCS.
Line 2: Reconstructed LCS string.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
AGGTAB
GXTXAYB

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Length of LCS: 4
LCS string: GTAB
================================================================================
*/

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    string s1, s2;
    if (!(cin >> s1 >> s2)) return 0;

    int m = s1.length();
    int n = s2.length();

    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));

    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (s1[i - 1] == s2[j - 1]) {
                dp[i][j] = 1 + dp[i - 1][j - 1];
            } else {
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }

    cout << "Length of LCS: " << dp[m][n] << "\n";

    string lcs = "";
    int i = m, j = n;
    while (i > 0 && j > 0) {
        if (s1[i - 1] == s2[j - 1]) {
            lcs.push_back(s1[i - 1]);
            i--; j--;
        } else if (dp[i - 1][j] > dp[i][j - 1]) {
            i--;
        } else {
            j--;
        }
    }
    reverse(lcs.begin(), lcs.end());

    cout << "LCS string: " << lcs << "\n";
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Subproblem: dp[i][j] stores the LCS length of prefixes S1[0...i-1] and S2[0...j-1].
2. Recurrence:
   dp[i][j] = 1 + dp[i-1][j-1]            if S1[i-1] == S2[j-1]
   dp[i][j] = max(dp[i-1][j], dp[i][j-1])  if S1[i-1] != S2[j-1]
3. Reconstruct string: Trace back from dp[m][n] towards dp[0][0].

Edge Cases:
- Disjoint character sets: Length = 0, empty string.
- S1 identical to S2: LCS is the entire string.
- One string empty: Length = 0.

Complexity Analysis:
- Time Complexity: O(M * N) where M and N are string lengths.
- Space Complexity: O(M * N) for DP table.
================================================================================
*/
