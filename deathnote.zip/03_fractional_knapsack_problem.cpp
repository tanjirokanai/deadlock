/*
================================================================================
Topic: Fractional Knapsack Problem
Module / Unit: Greedy Technique
================================================================================
Scenario Description:
A cargo transport drone has a maximum payload weight capacity W. A warehouse contains N liquid 
or granular chemicals, each with a given weight and market value. Fractional quantities of any chemical can be taken. 
Find the selection yielding maximum monetary value.

Input Format:
Line 1: Two integers N and W (number of chemicals and capacity).
Next N lines: Two integers value and weight for each chemical.

Output Format:
Line 1: Maximum total value formatted to 2 decimal places.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
3 50
60 10
100 20
120 30

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Maximum value in Knapsack = 240.00
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Item {
    double value;
    double weight;
};

bool compareRatio(const Item& a, const Item& b) {
    return (a.value / a.weight) > (b.value / b.weight);
}

int main() {
    int n;
    double capacity;
    if (!(cin >> n >> capacity)) return 0;

    vector<Item> items(n);
    for (int i = 0; i < n; i++) cin >> items[i].value >> items[i].weight;

    sort(items.begin(), items.end(), compareRatio);

    double current_weight = 0.0;
    double final_value = 0.0;

    for (int i = 0; i < n; i++) {
        if (current_weight + items[i].weight <= capacity) {
            current_weight += items[i].weight;
            final_value += items[i].value;
        } else {
            double remain = capacity - current_weight;
            final_value += items[i].value * (remain / items[i].weight);
            break;
        }
    }

    cout << fixed << setprecision(2);
    cout << "Maximum value in Knapsack = " << final_value << "\n";
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Compute the value-to-weight ratio (v[i] / w[i]) for each chemical.
2. Sort items in strictly descending order of their ratios.
3. Greedily take whole items starting from the highest ratio until capacity is exhausted.
4. If remaining capacity cannot fit the entire next item, take the exact fraction (remain / w[i]) of that item.
5. Greedy-choice property holds because any substitution with lower-density items reduces total value.

Edge Cases:
- Total capacity W >= sum of all weights: All items fully selected.
- Capacity W = 0: Total value is 0.00.
- All items have identical ratios: Any order yields the same maximal profit.

Complexity Analysis:
- Time Complexity: O(N log N) for sorting by ratio + O(N) for linear pass = O(N log N).
- Space Complexity: O(N) for storing item records.
================================================================================
*/
