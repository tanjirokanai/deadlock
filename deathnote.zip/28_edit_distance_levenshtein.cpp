/*
================================================================================
Topic: Edit Distance (Levenshtein Distance)
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
A query auto-correct system compares an input search string word1 with a dictionary entry word2. 
Compute the minimum edit operations (insert, delete, replace) required to convert word1 into word2.

Input Format:
Line 1: String word1.
Line 2: String word2.

Output Format:
Line 1: Minimum Edit Distance.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
intention
execution

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Minimum Edit Distance: 5
================================================================================
*/

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    string s1, s2;
    if (!(cin >> s1 >> s2)) return 0;

    int m = s1.length();
    int n = s2.length();

    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));

    for (int i = 0; i <= m; i++) dp[i][0] = i;
    for (int j = 0; j <= n; j++) dp[0][j] = j;

    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (s1[i - 1] == s2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1];
            } else {
                dp[i][j] = 1 + min({
                    dp[i - 1][j],    // Deletion
                    dp[i][j - 1],    // Insertion
                    dp[i - 1][j - 1] // Replacement
                });
            }
        }
    }

    cout << "Minimum Edit Distance: " << dp[m][n] << "\n";
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Subproblem: dp[i][j] is the edit distance between prefix s1[0...i-1] and s2[0...j-1].
2. Base cases: Converting empty string to length j requires j insertions (dp[0][j] = j); length i to empty takes i deletions (dp[i][0] = i).
3. If s1[i-1] == s2[j-1]: dp[i][j] = dp[i-1][j-1].
4. Otherwise: dp[i][j] = 1 + min(dp[i-1][j] (del), dp[i][j-1] (ins), dp[i-1][j-1] (rep)).

Edge Cases:
- Both strings identical: Distance = 0.
- One string empty: Distance = length of non-empty string.
- Completely disjoint characters: Distance = max(m, n).

Complexity Analysis:
- Time Complexity: O(M * N) where M and N are string lengths.
- Space Complexity: O(M * N) (can be reduced to O(N) using two rows).
================================================================================
*/
