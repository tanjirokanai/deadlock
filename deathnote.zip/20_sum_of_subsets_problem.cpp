/*
================================================================================
Topic: Sum of Subsets Problem
Module / Unit: Backtracking
================================================================================
Scenario Description:
A financial compliance officer audits a general ledger with N transaction amounts. 
Find all distinct subsets of transactions that sum exactly to Target.

Input Format:
Line 1: Two integers N and Target.
Line 2: N space-separated positive integers.

Output Format:
List of all matching subsets formatted as { x1 x2 ... }.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
6 30
5 10 12 13 15 18

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Subsets summing to 30:
{ 5 10 15 }
{ 5 12 13 }
{ 12 18 }
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int n, target;
vector<int> w;
vector<int> curr;
int found = 0;

void findSubsets(int idx, int curr_sum, int remain_sum) {
    if (curr_sum == target) {
        found++;
        cout << "{ ";
        for (int x : curr) cout << x << " ";
        cout << "}\n";
        return;
    }

    if (idx >= n || curr_sum + w[idx] > target || curr_sum + remain_sum < target) {
        return; // Bounding functions
    }

    // Include w[idx]
    curr.push_back(w[idx]);
    findSubsets(idx + 1, curr_sum + w[idx], remain_sum - w[idx]);
    curr.pop_back();

    // Exclude w[idx]
    findSubsets(idx + 1, curr_sum, remain_sum - w[idx]);
}

int main() {
    if (!(cin >> n >> target)) return 0;

    w.resize(n);
    int total_sum = 0;
    for (int i = 0; i < n; i++) {
        cin >> w[i];
        total_sum += w[i];
    }

    sort(w.begin(), w.end());

    cout << "Subsets summing to " << target << ":\n";
    findSubsets(0, 0, total_sum);
    if (found == 0) cout << "No subset found.\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Sort elements in non-decreasing order.
2. Build binary state-space tree where at level i we decide whether to include or exclude w[i].
3. Bounding Functions:
   - If curr_sum + w[idx] > target: Prune current branch and subsequent elements (since array is sorted).
   - If curr_sum + remain_sum < target: Prune because even taking all remaining elements cannot reach target.

Edge Cases:
- Target exceeds sum of all elements: Pruned immediately at root.
- Smallest element > Target: 0 subsets.
- Multiple duplicate values: Handled systematically.

Complexity Analysis:
- Time Complexity: O(2^N) worst-case; bounding functions heavily prune impractical branches.
- Space Complexity: O(N) auxiliary recursion stack.
================================================================================
*/
