/*
================================================================================
Topic: Prim's Algorithm for Minimum Spanning Tree
Module / Unit: Greedy Technique
================================================================================
Scenario Description:
A municipal water authority plans to interconnect V pumping stations using underground aqueducts. 
The cost of laying each aqueduct is an undirected weighted edge. Determine the minimum spanning tree cost and the list 
of chosen aqueducts starting from station 1.

Input Format:
Line 1: Two integers V and E (stations and possible aqueduct links).
Next E lines: Three integers u, v, w representing undirected link between u and v with cost w.

Output Format:
Line 1: Total Minimum Cabling Cost.
Next lines: Selected MST aqueducts.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
5 7
1 2 2
1 4 6
2 3 3
2 4 8
2 5 5
3 5 7
4 5 9

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Total Minimum Cabling Cost: 16
Selected MST Lines:
Line: 1 - 2 (Cost: 2)
Line: 2 - 3 (Cost: 3)
Line: 2 - 5 (Cost: 5)
Line: 1 - 4 (Cost: 6)
================================================================================
*/

#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Edge {
    int to;
    int weight;
};

int main() {
    int v, e;
    if (!(cin >> v >> e)) return 0;

    vector<vector<Edge>> adj(v + 1);
    for (int i = 0; i < e; i++) {
        int u, to, w;
        cin >> u >> to >> w;
        adj[u].push_back({to, w});
        adj[to].push_back({u, w});
    }

    priority_queue<pair<int, pair<int, int>>, 
                   vector<pair<int, pair<int, int>>>, 
                   greater<pair<int, pair<int, int>>>> pq;
    vector<bool> inMST(v + 1, false);

    pq.push({0, {1, -1}});
    long long total_cost = 0;
    vector<pair<pair<int, int>, int>> mst_edges;

    while (!pq.empty()) {
        auto [w, edge_info] = pq.top();
        pq.pop();
        int u = edge_info.first;
        int p = edge_info.second;

        if (inMST[u]) continue;
        inMST[u] = true;
        total_cost += w;

        if (p != -1) {
            mst_edges.push_back({{p, u}, w});
        }

        for (auto& edge : adj[u]) {
            if (!inMST[edge.to]) {
                pq.push({edge.weight, {edge.to, u}});
            }
        }
    }

    cout << "Total Minimum Cabling Cost: " << total_cost << "\n";
    cout << "Selected MST Lines:\n";
    for (auto& edge : mst_edges) {
        cout << "Line: " << edge.first.first << " - " << edge.first.second 
             << " (Cost: " << edge.second << ")\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Starts with a single vertex and grows the MST tree one edge at a time.
2. Maintain a min-heap of candidate edges connecting the current MST tree to outside vertices.
3. Greedily extract the minimum weight cut edge.
4. If target vertex is not yet in MST, mark it included, accumulate cost, and push its incident edges.
5. Continues until all V vertices are incorporated into the tree (V - 1 edges).

Edge Cases:
- Disconnected graph: Fails to span all vertices (mst_edges.size() < V - 1).
- Parallel edges: Min-heap naturally chooses lowest weight edge.

Complexity Analysis:
- Time Complexity: O(E log V) with binary heap priority queue.
- Space Complexity: O(V + E) for adjacency list and priority queue.
================================================================================
*/
