/*
================================================================================
Topic: N*N Queen Problem
Module / Unit: Backtracking
================================================================================
Scenario Description:
In an automated semiconductor board layout, N micro-sensors must be placed on an N x N grid 
such that no two sensors lie along the same horizontal, vertical, or diagonal communication beam. Place N queens on an N x N chessboard.

Input Format:
Line 1: An integer N (board dimension and number of queens).

Output Format:
Line 1: Total distinct valid placements.
Line 2+: Board configuration for the first valid solution.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Total distinct solutions: 2
Sample Solution 1:
. Q . .
. . . Q
Q . . .
. . Q .
================================================================================
*/

#include <iostream>
#include <vector>
#include <string>

using namespace std;

int n;
int solutions_count = 0;
vector<vector<string>> all_solutions;

bool isSafe(int row, int col, const vector<string>& board) {
    for (int i = 0; i < row; i++) {
        if (board[i][col] == 'Q') return false;
    }
    for (int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--) {
        if (board[i][j] == 'Q') return false;
    }
    for (int i = row - 1, j = col + 1; i >= 0 && j < n; i--, j++) {
        if (board[i][j] == 'Q') return false;
    }
    return true;
}

void solve(int row, vector<string>& board) {
    if (row == n) {
        solutions_count++;
        all_solutions.push_back(board);
        return;
    }
    for (int col = 0; col < n; col++) {
        if (isSafe(row, col, board)) {
            board[row][col] = 'Q';
            solve(row + 1, board);
            board[row][col] = '.'; // Backtrack
        }
    }
}

int main() {
    if (!(cin >> n)) return 0;

    vector<string> board(n, string(n, '.'));
    solve(0, board);

    cout << "Total distinct solutions: " << solutions_count << "\n";
    if (!all_solutions.empty()) {
        cout << "Sample Solution 1:\n";
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                cout << all_solutions[0][r][c] << (c + 1 == n ? "" : " ");
            }
            cout << "\n";
        }
    }
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Place queens row-by-row starting at row 0.
2. For each row, iterate through columns col = 0 to N - 1.
3. Check safety: No existing queen in same column, upper-left diagonal, or upper-right diagonal.
4. If safe, place queen ('Q') and recurse to row + 1.
5. If recursion fails or completes, backtrack by resetting cell to '.' and try next column.

Edge Cases:
- N = 1: 1 trivial solution.
- N = 2 or N = 3: 0 solutions exist.
- Large N (N >= 12): State-space grows factorially.

Complexity Analysis:
- Time Complexity: O(N!).
- Space Complexity: O(N^2) board representation and O(N) recursion stack.
================================================================================
*/
