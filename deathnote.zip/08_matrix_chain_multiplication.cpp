/*
================================================================================
Topic: Matrix-Chain Multiplication
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
A numerical mathematics library must compute the matrix product A1 x A2 x ... x An, 
where matrix Ai has dimensions p[i-1] x p[i]. Determine the parenthesization that minimizes the total scalar multiplications.

Input Format:
Line 1: An integer N (number of matrices).
Line 2: N + 1 space-separated integers representing dimension vector p.

Output Format:
Line 1: Minimum scalar multiplications.
Line 2: Optimal parenthesization representation.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4
10 30 5 60 10

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Minimum scalar multiplications: 4500
Optimal parenthesization: ((A1(A2A3))A4)
================================================================================
*/

#include <iostream>
#include <vector>
#include <climits>

using namespace std;

void printOptimalParens(const vector<vector<int>>& s, int i, int j) {
    if (i == j) {
        cout << "A" << i;
    } else {
        cout << "(";
        printOptimalParens(s, i, s[i][j]);
        printOptimalParens(s, s[i][j] + 1, j);
        cout << ")";
    }
}

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<int> p(n + 1);
    for (int i = 0; i <= n; i++) cin >> p[i];

    vector<vector<long long>> m(n + 1, vector<long long>(n + 1, 0));
    vector<vector<int>> s(n + 1, vector<int>(n + 1, 0));

    for (int L = 2; L <= n; L++) {
        for (int i = 1; i <= n - L + 1; i++) {
            int j = i + L - 1;
            m[i][j] = LLONG_MAX;
            for (int k = i; k < j; k++) {
                long long q = m[i][k] + m[k + 1][j] + 1LL * p[i - 1] * p[k] * p[j];
                if (q < m[i][j]) {
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }
        }
    }

    cout << "Minimum scalar multiplications: " << m[1][n] << "\n";
    cout << "Optimal parenthesization: ";
    printOptimalParens(s, 1, n);
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Matrix multiplication is associative: (AB)C = A(BC), but operations count differs significantly.
2. Let m[i][j] be minimum scalar multiplications to compute Ai...Aj.
3. Recurrence:
   m[i][j] = min_{i <= k < j} { m[i][k] + m[k+1][j] + p[i-1]*p[k]*p[j] }
4. Bottom-up iteration by chain length L = 2, 3, ..., n.
5. Auxiliary table s[i][j] stores the optimal split index k for recursive reconstruction.

Edge Cases:
- Single matrix (N = 1): 0 multiplications needed.
- Square matrices of identical size: Any parenthesization costs (N-1)*d^3.

Complexity Analysis:
- Time Complexity: O(N^3) due to 3 nested loops (chain length, starting index, split point).
- Space Complexity: O(N^2) for memoization and split tables.
================================================================================
*/
