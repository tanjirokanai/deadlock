/*
================================================================================
Topic: Container Loading Problem
Module / Unit: Greedy Technique
================================================================================
Scenario Description:
A cargo port must load containers onto a freight vessel with a maximum weight capacity W. 
There are N containers at the dock, each with an integer weight. The port authority wishes to load 
the maximum number of containers onto the ship without violating the ship's weight limit.

Input Format:
Line 1: Two integers N and W (number of containers and ship capacity).
Line 2: N space-separated integers representing container weights.

Output Format:
Line 1: Maximum number of containers loaded.
Line 2: Total weight loaded.
Line 3: Weights of the selected containers in sorted order.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
6 16
2 5 3 10 7 4

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Maximum containers loaded: 4
Total weight loaded: 14
Loaded container weights: 2 3 4 5
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    long long w;
    if (!(cin >> n >> w)) return 0;

    vector<long long> weights(n);
    for (int i = 0; i < n; i++) cin >> weights[i];

    sort(weights.begin(), weights.end());

    int count = 0;
    long long total_weight = 0;
    vector<long long> loaded;

    for (int i = 0; i < n; i++) {
        if (total_weight + weights[i] <= w) {
            total_weight += weights[i];
            loaded.push_back(weights[i]);
            count++;
        } else {
            break;
        }
    }

    cout << "Maximum containers loaded: " << count << "\n";
    cout << "Total weight loaded: " << total_weight << "\n";
    cout << "Loaded container weights: ";
    for (size_t i = 0; i < loaded.size(); i++) {
        cout << loaded[i] << (i + 1 == loaded.size() ? "" : " ");
    }
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Greedy Choice: To maximize the count of items loaded within weight W, always prioritize the lightest available container.
2. Sort container weights in non-decreasing order: w[0] <= w[1] <= ... <= w[n-1].
3. Greedily select items from index 0 upwards until the accumulated weight plus the next weight exceeds W.
4. Proof of Optimality: Any optimal solution that omits the smallest available element can substitute a heavier element with the smaller one without increasing total weight or decreasing count.

Edge Cases:
- Empty input (N = 0) or capacity W = 0: 0 containers loaded.
- Smallest container weight exceeds W: 0 containers loaded.
- Sum of all containers <= W: All N containers loaded.
- All containers identical weight.

Complexity Analysis:
- Time Complexity: O(N log N) dominated by sorting the container weights.
- Space Complexity: O(N) to store container weights (or O(1) auxiliary if sorted in-place).
================================================================================
*/
