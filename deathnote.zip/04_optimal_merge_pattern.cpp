/*
================================================================================
Topic: Optimal Merge Pattern
Module / Unit: Greedy Technique
================================================================================
Scenario Description:
A database engine must merge N sorted database shard files of sizes s[1], s[2], ..., s[n] into 
a single unified sorted table. Merging two files of size X and Y incurs X + Y record comparison cost. Determine the 
minimal cumulative record comparisons required.

Input Format:
Line 1: An integer N (number of files).
Line 2: N space-separated integers representing file sizes.

Output Format:
Line 1: Minimum total merge cost.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
6
2 3 4 5 6 7

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Minimum total merge cost: 68
================================================================================
*/

#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    int n;
    if (!(cin >> n)) return 0;

    priority_queue<long long, vector<long long>, greater<long long>> minHeap;
    for (int i = 0; i < n; i++) {
        long long sz;
        cin >> sz;
        minHeap.push(sz);
    }

    long long total_cost = 0;
    while (minHeap.size() > 1) {
        long long a = minHeap.top(); minHeap.pop();
        long long b = minHeap.top(); minHeap.pop();
        long long merged = a + b;
        total_cost += merged;
        minHeap.push(merged);
    }

    cout << "Minimum total merge cost: " << total_cost << "\n";
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Insert all file sizes into a Min-Heap (priority queue).
2. While heap size > 1:
   a. Extract two smallest file sizes (a and b).
   b. Cost of this intermediate merge is (a + b).
   c. Add (a + b) to cumulative cost.
   d. Insert merged size (a + b) back into the heap.
3. This is an application of Huffman's algorithm on an extended binary tree where leaves represent original file sizes.

Edge Cases:
- N = 1: File is already merged; total cost = 0.
- N = 2: Exactly one merge operation; cost = a + b.
- Extremely large file sizes: Accumulator must use 64-bit integers (`long long`) to prevent overflow.

Complexity Analysis:
- Time Complexity: O(N log N) because we perform (N - 1) merges, each extracting and inserting into min-heap in O(log N).
- Space Complexity: O(N) to maintain the min-heap.
================================================================================
*/
