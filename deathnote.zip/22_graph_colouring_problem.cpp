/*
================================================================================
Topic: Graph Colouring Problem
Module / Unit: Backtracking
================================================================================
Scenario Description:
A wireless telecom regulator must assign frequency spectrum channels (colors) to V broadcast towers. 
If two towers have overlapping coverage (an edge), they cannot use the same channel. Determine whether an assignment 
using at most M channels exists.

Input Format:
Line 1: Three integers V, E, and M (towers, interference edges, max available colors).
Next E lines: Two integers u and v denoting interference between tower u and tower v.

Output Format:
Line 1: Status ("Solution exists!" or "No solution exists using M colors.").
Line 2+: Color assigned to each tower (1 to M).

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4 5 3
1 2
1 3
1 4
2 3
3 4

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Solution exists!
Tower color assignments:
Tower 1 -> Color 1
Tower 2 -> Color 2
Tower 3 -> Color 3
Tower 4 -> Color 2
================================================================================
*/

#include <iostream>
#include <vector>

using namespace std;

int v, e, m;
vector<vector<int>> adj;
vector<int> color;

bool isSafe(int node, int c) {
    for (int nxt : adj[node]) {
        if (color[nxt] == c) return false;
    }
    return true;
}

bool graphColoringUtil(int node) {
    if (node > v) return true;

    for (int c = 1; c <= m; c++) {
        if (isSafe(node, c)) {
            color[node] = c;
            if (graphColoringUtil(node + 1)) return true;
            color[node] = 0; // Backtrack
        }
    }
    return false;
}

int main() {
    if (!(cin >> v >> e >> m)) return 0;

    adj.assign(v + 1, vector<int>());
    color.assign(v + 1, 0);

    for (int i = 0; i < e; i++) {
        int u, to;
        cin >> u >> to;
        adj[u].push_back(to);
        adj[to].push_back(u);
    }

    if (graphColoringUtil(1)) {
        cout << "Solution exists!\n";
        cout << "Tower color assignments:\n";
        for (int i = 1; i <= v; i++) {
            cout << "Tower " << i << " -> Color " << color[i] << "\n";
        }
    } else {
        cout << "No solution exists using " << m << " colors.\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Assign colors 1...M to vertices 1...V recursively using depth-first search.
2. For current node, try colors c = 1 to M.
3. Check safety: ensure none of the adjacent neighbors currently share color c.
4. If a valid color is assigned, proceed to node + 1. If no color works, backtrack.
5. Base case: When node > V, all vertices have been validly colored.

Edge Cases:
- M = 1: Only solvable if graph has 0 edges.
- Complete Graph K_n: Requires exactly M = n colors.
- Bipartite graph: Always 2-colorable.

Complexity Analysis:
- Time Complexity: O(M^V) worst-case.
- Space Complexity: O(V + E) for adjacency list and recursion depth O(V).
================================================================================
*/
