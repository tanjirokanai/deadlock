/*
================================================================================
Topic: Dijkstra's Algorithm (SSSP)
Module / Unit: Graph Algorithms
================================================================================
Scenario Description:
A delivery fleet must route packages from a regional warehouse (source S) to V destination 
neighborhood hubs. Non-negative road travel latencies are provided. Compute the shortest travel duration from S to all hubs.

Input Format:
Line 1: Three integers V, E, and S (vertices, edges, source node).
Next E lines: Three integers u, v, w representing directed edge from u to v with travel time w.

Output Format:
V lines: Destination hub and its shortest travel duration (or INF).

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
5 6 1
1 2 4
1 3 2
2 4 5
3 2 1
3 4 8
4 5 3

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Shortest distances from source hub 1:
Hub 1: 0
Hub 2: 3
Hub 3: 2
Hub 4: 8
Hub 5: 11
================================================================================
*/

#include <iostream>
#include <vector>
#include <queue>

using namespace std;

const long long INF = 1e18;

struct Edge {
    int to;
    long long weight;
};

int main() {
    int v, e, src;
    if (!(cin >> v >> e >> src)) return 0;

    vector<vector<Edge>> adj(v + 1);
    for (int i = 0; i < e; i++) {
        int u, to;
        long long w;
        cin >> u >> to >> w;
        adj[u].push_back({to, w});
    }

    priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<pair<long long, int>>> pq;
    vector<long long> dist(v + 1, INF);

    dist[src] = 0;
    pq.push({0, src});

    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();

        if (d > dist[u]) continue;

        for (auto& edge : adj[u]) {
            if (dist[u] + edge.weight < dist[edge.to]) {
                dist[edge.to] = dist[u] + edge.weight;
                pq.push({dist[edge.to], edge.to});
            }
        }
    }

    cout << "Shortest distances from source hub " << src << ":\n";
    for (int i = 1; i <= v; i++) {
        cout << "Hub " << i << ": ";
        if (dist[i] == INF) cout << "INF\n";
        else cout << dist[i] << "\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Maintain a min-priority queue of vertices ordered by provisional distance dist[u].
2. Set dist[src] = 0 and all other dist[v] = INF.
3. Greedily extract vertex u with minimal dist[u].
4. Relax every outgoing edge (u, v):
   if dist[u] + w(u, v) < dist[v] -> dist[v] = dist[u] + w(u, v); push into pq.
5. Fails if negative edge weights exist (greedy choice assumption violated).

Edge Cases:
- Disconnected graph: Unreachable vertices retain dist = INF.
- Self-loops: Safely ignored if positive weight.
- Negative weights: Algorithm does not support negative weights; use Bellman-Ford.

Complexity Analysis:
- Time Complexity: O((V + E) log V) using binary min-heap.
- Space Complexity: O(V + E) for adjacency list and priority queue.
================================================================================
*/
