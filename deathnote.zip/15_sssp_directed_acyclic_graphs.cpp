/*
================================================================================
Topic: Single-Source Shortest Paths in DAGs
Module / Unit: Graph Algorithms
================================================================================
Scenario Description:
A compiler analyzes instruction scheduling represented as a Directed Acyclic Graph (DAG) 
where edges have latency weights (possibly negative). Compute single-source shortest path latencies in optimal linear time.

Input Format:
Line 1: Three integers V, E, and S (vertices, edges, source node).
Next E lines: Three integers u, v, w representing directed dependency from u to v with latency w.

Output Format:
V lines: Node index and shortest latency from source.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
6 10 2
1 2 5
1 3 3
2 3 2
2 4 6
3 4 7
3 5 4
3 6 2
4 5 -1
4 6 1
5 6 -2

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Shortest latencies from source node 2:
Node 1: INF
Node 2: 0
Node 3: 2
Node 4: 6
Node 5: 5
Node 6: 3
================================================================================
*/

#include <iostream>
#include <vector>
#include <stack>

using namespace std;

const long long INF = 1e18;

struct Edge {
    int to;
    long long weight;
};

void topoSort(int u, const vector<vector<Edge>>& adj, vector<bool>& visited, stack<int>& st) {
    visited[u] = true;
    for (auto& edge : adj[u]) {
        if (!visited[edge.to]) topoSort(edge.to, adj, visited, st);
    }
    st.push(u);
}

int main() {
    int v, e, src;
    if (!(cin >> v >> e >> src)) return 0;

    vector<vector<Edge>> adj(v + 1);
    for (int i = 0; i < e; i++) {
        int u, to;
        long long w;
        cin >> u >> to >> w;
        adj[u].push_back({to, w});
    }

    vector<bool> visited(v + 1, false);
    stack<int> st;
    for (int i = 1; i <= v; i++) {
        if (!visited[i]) topoSort(i, adj, visited, st);
    }

    vector<long long> dist(v + 1, INF);
    dist[src] = 0;

    while (!st.empty()) {
        int u = st.top();
        st.pop();

        if (dist[u] != INF) {
            for (auto& edge : adj[u]) {
                if (dist[u] + edge.weight < dist[edge.to]) {
                    dist[edge.to] = dist[u] + edge.weight;
                }
            }
        }
    }

    cout << "Shortest latencies from source node " << src << ":\n";
    for (int i = 1; i <= v; i++) {
        cout << "Node " << i << ": ";
        if (dist[i] == INF) cout << "INF\n";
        else cout << dist[i] << "\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Find a topological ordering of the vertices using DFS in O(V + E).
2. Set dist[src] = 0, all other distances = INF.
3. Process vertices strictly in topological order.
4. For each vertex u, relax all outgoing edges (u, v):
   dist[v] = min(dist[v], dist[u] + w(u, v)).
5. Because DAG has no cycles, when vertex v is processed, its shortest path is already finalized.
6. Operates correctly even in the presence of negative edge weights.

Edge Cases:
- Graph with cycles: Not a DAG; topological sort fails.
- Source placed after other nodes in topological order: Preceding nodes remain unreachable (INF).
- Negative weights: Supported safely since cycles cannot exist.

Complexity Analysis:
- Time Complexity: O(V + E) linear time.
- Space Complexity: O(V + E) for adjacency list and recursion stack.
================================================================================
*/
