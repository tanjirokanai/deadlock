/*
================================================================================
Topic: 2-Approximation Algorithm for Vertex Cover
Module / Unit: Approximation Algorithms
================================================================================
Scenario Description:
A smart city project requires placing surveillance cameras at road intersections to monitor all street segments. 
A camera at intersection u monitors all streets incident to u. The Minimum Vertex Cover problem is NP-Hard. Implement the 
standard 2-approximation greedy maximal matching algorithm to select camera locations in polynomial time.

Input Format:
Line 1: Two integers V and E (intersections and street segments).
Next E lines: Two integers u and v representing an undirected street between u and v.

Output Format:
Line 1: Total CCTV guard posts selected.
Line 2: Selected junction IDs.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
7 7
1 2
2 3
3 4
3 5
4 5
4 6
5 7

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Total CCTV guard posts selected: 4
Guard post junction IDs: 1 2 3 4
================================================================================
*/

#include <iostream>
#include <vector>

using namespace std;

struct Edge {
    int u, v;
};

int main() {
    int v, e;
    if (!(cin >> v >> e)) return 0;

    vector<Edge> edges(e);
    for (int i = 0; i < e; i++) {
        cin >> edges[i].u >> edges[i].v;
    }

    vector<bool> visited(v + 1, false);
    vector<int> cover;

    for (const auto& edge : edges) {
        int u = edge.u;
        int w = edge.v;
        if (!visited[u] && !visited[w]) {
            visited[u] = true;
            visited[w] = true;
            cover.push_back(u);
            cover.push_back(w);
        }
    }

    cout << "Total CCTV guard posts selected: " << cover.size() << "\n";
    cout << "Guard post junction IDs: ";
    for (size_t i = 0; i < cover.size(); i++) {
        cout << cover[i] << (i + 1 == cover.size() ? "" : " ");
    }
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Initialize vertex cover C = empty set.
2. Iterate through edges (u, v):
   - If neither u nor v is already in C:
     - Add BOTH u and v to C.
     - Mark both u and v as visited (implicitly removing all edges incident to u and v).
3. The selected edges form a maximal matching M.
4. Any valid vertex cover must include at least one endpoint from each edge in matching M: |OPT| >= |M|.
5. Algorithm picks 2|M| vertices: |C| = 2|M| <= 2|OPT|. Hence, approximation ratio is at most 2.

Edge Cases:
- Disconnected graph: Processes each component independently.
- Graph with no edges (E = 0): Cover is empty (0 vertices).
- Star graph (1 central hub, k leaves): Approximation picks 2 vertices, OPT is 1 (ratio = 2).

Complexity Analysis:
- Time Complexity: O(V + E) linear time.
- Space Complexity: O(V + E) for edge list and boolean visited array.
================================================================================
*/
