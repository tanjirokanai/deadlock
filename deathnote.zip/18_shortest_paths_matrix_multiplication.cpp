/*
================================================================================
Topic: Shortest Paths and Matrix Multiplication
Module / Unit: Graph Algorithms
================================================================================
Scenario Description:
In algebraic graph routing, all-pairs shortest paths can be computed via repeated matrix multiplication 
under the min-plus semiring (tropical semiring). Given adjacency matrix W, compute all-pairs distances using logarithmic 
matrix squaring in ceil(log2(V - 1)) multiplications.

Input Format:
Line 1: An integer V (number of vertices).
Next V lines: V integers representing initial weight matrix W (9999 represents infinity).

Output Format:
V lines: Final shortest path distance matrix.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4
0 3 9999 7
9999 0 1 9999
9999 9999 0 2
9999 9999 9999 0

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Final Shortest Path Distance Matrix:
0 3 4 6
INF 0 1 3
INF INF 0 2
INF INF INF 0
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const long long INF = 1e15;

vector<vector<long long>> extendShortestPaths(const vector<vector<long long>>& L, const vector<vector<long long>>& W, int n) {
    vector<vector<long long>> L_prime(n, vector<long long>(n, INF));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                if (L[i][k] != INF && W[k][j] != INF) {
                    L_prime[i][j] = min(L_prime[i][j], L[i][k] + W[k][j]);
                }
            }
        }
    }
    return L_prime;
}

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<vector<long long>> W(n, vector<long long>(n));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            long long val;
            cin >> val;
            if (val >= 9999 && i != j) W[i][j] = INF;
            else W[i][j] = val;
        }
    }

    vector<vector<long long>> L = W;
    int m = 1;
    while (m < n - 1) {
        L = extendShortestPaths(L, L, n);
        m *= 2;
    }

    cout << "Final Shortest Path Distance Matrix:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (L[i][j] >= INF / 2) cout << "INF";
            else cout << L[i][j];
            cout << (j + 1 == n ? "" : " ");
        }
        cout << "\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Replaces ordinary matrix multiplication operations (+, *) with min-plus operations (min, +).
2. L^(2m) = L^(m) * L^(m) where L'[i][j] = min_k (L[i][k] + L[k][j]).
3. By repeated squaring, compute L^(1), L^(2), L^(4), ..., L^(2^ceil(log2(V-1))).
4. Guarantees convergence since any simple shortest path contains at most V - 1 edges.

Edge Cases:
- Graph with 1 or 2 vertices: Requires 0 or 1 squaring operations.
- Disconnected graph: Elements remain at infinity.

Complexity Analysis:
- Time Complexity: O(V^3 log V) since each min-plus matrix product is O(V^3) and performed log2(V) times.
- Space Complexity: O(V^2) for matrix buffers.
================================================================================
*/
