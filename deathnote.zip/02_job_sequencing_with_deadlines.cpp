/*
================================================================================
Topic: Job Sequencing with Deadlines
Module / Unit: Greedy Technique
================================================================================
Scenario Description:
A cloud server schedules N processing jobs. Each job requires 1 unit of time, has an integer deadline, 
and yields a specific monetary profit if executed on or before its deadline. Schedule jobs on a single CPU 
to maximize total profit.

Input Format:
Line 1: An integer N (number of jobs).
Next N lines: A string job_id and two integers deadline and profit.

Output Format:
Line 1: Count of jobs scheduled and total earned profit.
Line 2: Scheduled sequence of job IDs.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
5
J1 2 100
J2 1 19
J3 2 27
J4 1 25
J5 3 15

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Jobs completed: 3, Total Profit: 142
Scheduled order of jobs: J3 J1 J5
================================================================================
*/

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

struct Job {
    string id;
    int deadline;
    int profit;
};

bool compareJob(const Job& a, const Job& b) {
    return a.profit > b.profit;
}

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<Job> jobs(n);
    int max_deadline = 0;
    for (int i = 0; i < n; i++) {
        cin >> jobs[i].id >> jobs[i].deadline >> jobs[i].profit;
        max_deadline = max(max_deadline, jobs[i].deadline);
    }

    sort(jobs.begin(), jobs.end(), compareJob);

    vector<string> schedule(max_deadline + 1, "");
    int count = 0;
    long long total_profit = 0;

    for (int i = 0; i < n; i++) {
        for (int slot = min(max_deadline, jobs[i].deadline); slot >= 1; slot--) {
            if (schedule[slot] == "") {
                schedule[slot] = jobs[i].id;
                total_profit += jobs[i].profit;
                count++;
                break;
            }
        }
    }

    cout << "Jobs completed: " << count << ", Total Profit: " << total_profit << "\n";
    cout << "Scheduled order of jobs: ";
    bool first = true;
    for (int slot = 1; slot <= max_deadline; slot++) {
        if (schedule[slot] != "") {
            if (!first) cout << " ";
            cout << schedule[slot];
            first = false;
        }
    }
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Sort all submitted jobs in descending order of profit.
2. Initialize time slots from 1 up to max(deadline) as empty.
3. For each job in decreasing profit order, find the latest available free time slot t <= job.deadline.
4. Placing the job as late as possible preserves earlier slots for jobs with tighter deadlines.
5. If an available slot is found, mark it occupied and accumulate profit.

Edge Cases:
- All jobs have deadline = 1: Only the single highest-profit job can be scheduled.
- Deadlines greater than total number of jobs N: Validly assigned up to min(max_deadline, N).
- Zero profit jobs: Handled naturally; greedily picked last.

Complexity Analysis:
- Time Complexity: O(N log N) for sorting + O(N * min(N, max_deadline)) for slot finding. With Disjoint Set Union (DSU), slot lookup reduces to O(N * alpha(D)).
- Space Complexity: O(max_deadline + N) for schedule tracking and job storage.
================================================================================
*/
