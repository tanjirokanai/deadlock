/*
================================================================================
Topic: Optimal Binary Search Trees
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
A high-frequency key-value store indexes N sorted keys k1 < k2 < ... < kn with known access frequencies 
p1, p2, ..., pn. Construct an Optimal Binary Search Tree (OBST) that minimizes the total expected key comparison cost.

Input Format:
Line 1: An integer N (number of keys).
Line 2: N space-separated integers representing search frequencies.

Output Format:
Line 1: Minimum expected search cost.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
3
34 8 50

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Minimum expected search cost: 142
================================================================================
*/

#include <iostream>
#include <vector>
#include <climits>

using namespace std;

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<int> freq(n);
    for (int i = 0; i < n; i++) cin >> freq[i];

    vector<vector<int>> cost(n, vector<int>(n, 0));

    for (int i = 0; i < n; i++) cost[i][i] = freq[i];

    for (int L = 2; L <= n; L++) {
        for (int i = 0; i <= n - L; i++) {
            int j = i + L - 1;
            cost[i][j] = INT_MAX;
            int sum_freq = 0;
            for (int k = i; k <= j; k++) sum_freq += freq[k];

            for (int r = i; r <= j; r++) {
                int c = ((r > i) ? cost[i][r - 1] : 0) +
                        ((r < j) ? cost[r + 1][j] : 0) +
                        sum_freq;
                if (c < cost[i][j]) cost[i][j] = c;
            }
        }
    }

    cout << "Minimum expected search cost: " << cost[0][n - 1] << "\n";
    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Let cost[i][j] be the minimum search cost for keys from index i to j.
2. If key r is selected as the root of subtree keys i...j:
   cost[i][j] = cost[i][r-1] + cost[r+1][j] + sum(freq[k] for k from i to j).
3. Adding sum of frequencies accounts for every node in the subtree being one level deeper.
4. Evaluate over increasing chain length L from 2 to N.

Edge Cases:
- Single key (N = 1): Cost = freq[0].
- All frequencies equal: Balanced BST is optimal.
- Monotonically increasing frequencies: Skewed hierarchy placing heaviest keys near root.

Complexity Analysis:
- Time Complexity: O(N^3) standard DP (can be optimized to O(N^2) using Knuth's optimization).
- Space Complexity: O(N^2) to maintain subtree cost table.
================================================================================
*/
