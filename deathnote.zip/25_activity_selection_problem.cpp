/*
================================================================================
Topic: Activity Selection Problem
Module / Unit: Greedy Technique
================================================================================
Scenario Description:
A conference auditorium can host only one workshop at a time. N speakers propose workshops 
with start time S[i] and finish time F[i]. Determine the maximum number of compatible workshops that can be scheduled.

Input Format:
Line 1: An integer N (number of proposed workshops).
Line 2: N space-separated integers representing start times.
Line 3: N space-separated integers representing finish times.

Output Format:
Line 1: Maximum seminars scheduled.
Line 2: Selected intervals [start, finish].

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
6
1 3 0 5 8 5
2 4 6 7 9 9

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Maximum seminars scheduled: 4
Selected Seminar intervals: [1, 2] [3, 4] [5, 7] [8, 9]
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Activity {
    int id;
    int start;
    int finish;
};

bool compareActivity(const Activity& a, const Activity& b) {
    return a.finish < b.finish;
}

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<Activity> act(n);
    for (int i = 0; i < n; i++) {
        act[i].id = i + 1;
        cin >> act[i].start;
    }
    for (int i = 0; i < n; i++) cin >> act[i].finish;

    sort(act.begin(), act.end(), compareActivity);

    vector<Activity> selected;
    if (n > 0) {
        selected.push_back(act[0]);
        int last_finish = act[0].finish;

        for (int i = 1; i < n; i++) {
            if (act[i].start >= last_finish) {
                selected.push_back(act[i]);
                last_finish = act[i].finish;
            }
        }
    }

    cout << "Maximum seminars scheduled: " << selected.size() << "\n";
    cout << "Selected Seminar intervals: ";
    for (size_t i = 0; i < selected.size(); i++) {
        cout << "[" << selected[i].start << ", " << selected[i].finish << "]" 
             << (i + 1 == selected.size() ? "" : " ");
    }
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Sort all activities by finish time in non-decreasing order.
2. Greedily select the activity that finishes earliest (leaves maximum possible time for remaining activities).
3. For every subsequent activity, if its start time >= finish time of last scheduled activity, include it.
4. Proof of optimality: An optimal schedule with an activity finishing later can replace it with the earliest finishing one without conflicts.

Edge Cases:
- Activities with identical finish times: Sort order handles ties cleanly.
- Overlapping activities spanning entire time horizon: Only 1 activity scheduled.
- N = 0: 0 activities scheduled.

Complexity Analysis:
- Time Complexity: O(N log N) for sorting + O(N) linear scan = O(N log N).
- Space Complexity: O(N) to store activities.
================================================================================
*/
