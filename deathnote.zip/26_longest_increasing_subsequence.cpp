/*
================================================================================
Topic: Longest Increasing Subsequence (LIS)
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
An algorithmic financial trading analyst examines N consecutive daily stock prices. 
Find the maximum length of a strictly increasing price run and reconstruct the optimal sequence of prices.

Input Format:
Line 1: An integer N (number of days).
Line 2: N space-separated integers representing stock prices.

Output Format:
Line 1: Length of Longest Increasing Subsequence.
Line 2: Optimal Price Sequence.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
8
10 22 9 33 21 50 41 60

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Length of Longest Increasing Subsequence: 5
Optimal Price Sequence: 10 22 33 50 60
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    if (!(cin >> n)) return 0;

    vector<int> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];

    vector<int> dp(n, 1);
    vector<int> parent(n, -1);

    int max_len = 1;
    int best_end = 0;

    for (int i = 1; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (a[j] < a[i] && dp[j] + 1 > dp[i]) {
                dp[i] = dp[j] + 1;
                parent[i] = j;
            }
        }
        if (dp[i] > max_len) {
            max_len = dp[i];
            best_end = i;
        }
    }

    vector<int> lis;
    int curr = best_end;
    while (curr != -1) {
        lis.push_back(a[curr]);
        curr = parent[curr];
    }
    reverse(lis.begin(), lis.end());

    cout << "Length of Longest Increasing Subsequence: " << max_len << "\n";
    cout << "Optimal Price Sequence: ";
    for (size_t i = 0; i < lis.size(); i++) {
        cout << lis[i] << (i + 1 == lis.size() ? "" : " ");
    }
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Let dp[i] be the length of the LIS ending at index i.
2. Recurrence:
   dp[i] = 1 + max_{0 <= j < i, a[j] < a[i]} (dp[j]).
3. Track parent indices parent[i] to backtrack and reconstruct the exact sequence.
4. (Note: Length alone can also be computed in O(N log N) using patience sorting / binary search tails).

Edge Cases:
- Strictly decreasing array (e.g., 5 4 3 2 1): LIS length = 1.
- Strictly increasing array: LIS length = N.
- All equal elements: LIS length = 1 (strictly increasing requirement).

Complexity Analysis:
- Time Complexity: O(N^2) for dynamic programming with full sequence reconstruction.
- Space Complexity: O(N) for dp and parent arrays.
================================================================================
*/
