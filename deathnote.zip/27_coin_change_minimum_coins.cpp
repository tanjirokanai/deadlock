/*
================================================================================
Topic: Coin Change - Minimum Coins
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
An ATM dispenses currency using N distinct note denominations. For a requested withdrawal amount V, 
compute the minimum number of notes needed and list the denominations used.

Input Format:
Line 1: Two integers N and V (number of denominations and withdrawal amount).
Line 2: N space-separated integers representing coin denominations.

Output Format:
Line 1: Minimum coins required (or -1).
Line 2: Denomination breakdown.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
3 11
1 2 5

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Minimum coins required: 3
Coin breakdown: 5 5 1
================================================================================
*/

#include <iostream>
#include <vector>
#include <climits>

using namespace std;

int main() {
    int n, v;
    if (!(cin >> n >> v)) return 0;

    vector<int> coins(n);
    for (int i = 0; i < n; i++) cin >> coins[i];

    const int INF = 1e9;
    vector<int> dp(v + 1, INF);
    vector<int> last_coin(v + 1, -1);

    dp[0] = 0;

    for (int i = 1; i <= v; i++) {
        for (int c : coins) {
            if (i >= c && dp[i - c] != INF) {
                if (dp[i - c] + 1 < dp[i]) {
                    dp[i] = dp[i - c] + 1;
                    last_coin[i] = c;
                }
            }
        }
    }

    if (dp[v] == INF) {
        cout << "Minimum coins required: -1\n";
    } else {
        cout << "Minimum coins required: " << dp[v] << "\n";
        cout << "Coin breakdown: ";
        int rem = v;
        while (rem > 0) {
            int c = last_coin[rem];
            cout << c << (rem - c > 0 ? " " : "");
            rem -= c;
        }
        cout << "\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Subproblem: dp[i] is the minimum coins needed to make amount i.
2. Recurrence:
   dp[i] = min_{c in coins, c <= i} (dp[i - c] + 1).
3. Base case: dp[0] = 0; all other dp initialized to INF.
4. last_coin[i] records the coin used to transition into state i for path reconstruction.

Edge Cases:
- Amount V cannot be formed: Outputs -1.
- Amount V = 0: 0 coins.
- Greedy approach fails for arbitrary coin systems (e.g., coins {1, 3, 4} for V=6: Greedy gives 4+1+1 (3 coins), DP gives 3+3 (2 coins)).

Complexity Analysis:
- Time Complexity: O(N * V).
- Space Complexity: O(V) for DP table and coin tracker.
================================================================================
*/
