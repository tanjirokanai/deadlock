/*
================================================================================
Topic: The Bellman-Ford Algorithm
Module / Unit: Graph Algorithms
================================================================================
Scenario Description:
A financial arbitrage detection engine inspects exchange rates across V currencies. 
Negative-log weights can yield negative cycles (arbitrage opportunities). Compute shortest paths from source currency S 
and detect whether an arbitrage negative-weight cycle exists.

Input Format:
Line 1: Three integers V, E, and S (currencies, exchange routes, source currency).
Next E lines: Three integers u, v, w representing directed exchange cost from u to v.

Output Format:
Line 1: Status ("No negative weight cycle detected." or "Graph contains negative weight cycle").
Following lines: Shortest distances to all reachable nodes.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
5 8 1
1 2 -1
1 3 4
2 3 3
2 4 2
2 5 2
4 2 1
4 3 5
5 4 -3

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
No negative weight cycle detected.
Shortest distances from source currency 1:
Node 1: 0
Node 2: -1
Node 3: 2
Node 4: -2
Node 5: 1
================================================================================
*/

#include <iostream>
#include <vector>

using namespace std;

const long long INF = 1e18;

struct Edge {
    int u, v;
    long long w;
};

int main() {
    int v, e, src;
    if (!(cin >> v >> e >> src)) return 0;

    vector<Edge> edges(e);
    for (int i = 0; i < e; i++) {
        cin >> edges[i].u >> edges[i].v >> edges[i].w;
    }

    vector<long long> dist(v + 1, INF);
    dist[src] = 0;

    for (int i = 1; i <= v - 1; i++) {
        for (const auto& edge : edges) {
            if (dist[edge.u] != INF && dist[edge.u] + edge.w < dist[edge.v]) {
                dist[edge.v] = dist[edge.u] + edge.w;
            }
        }
    }

    bool has_negative_cycle = false;
    for (const auto& edge : edges) {
        if (dist[edge.u] != INF && dist[edge.u] + edge.w < dist[edge.v]) {
            has_negative_cycle = true;
            break;
        }
    }

    if (has_negative_cycle) {
        cout << "Graph contains negative weight cycle\n";
    } else {
        cout << "No negative weight cycle detected.\n";
        cout << "Shortest distances from source currency " << src << ":\n";
        for (int i = 1; i <= v; i++) {
            cout << "Node " << i << ": ";
            if (dist[i] == INF) cout << "INF\n";
            else cout << dist[i] << "\n";
        }
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Initialize dist[src] = 0, all other distances = INF.
2. Relax all E edges repeatedly (V - 1) times.
3. Any simple shortest path has at most (V - 1) edges. Thus, distances converge in (V - 1) passes.
4. Perform a V-th relaxation pass: if any distance further decreases (dist[u] + w < dist[v]), a negative cycle is reachable.

Edge Cases:
- Disconnected negative cycle not reachable from source: Will not be detected unless distance initialization is modified (e.g., all set to 0).
- Multiple edges between same pair: Minimum weight edge dominates.

Complexity Analysis:
- Time Complexity: O(V * E).
- Space Complexity: O(V + E) to store edge list and distances.
================================================================================
*/
