/*
================================================================================
Topic: Transitive Closure of a Graph (Warshall's Algorithm)
Module / Unit: Graph Algorithms
================================================================================
Scenario Description:
A system architect analyzes access reachability between V microservices. Given direct RPC invocation 
links, construct the boolean reachability matrix indicating if service u can reach service v directly or indirectly.

Input Format:
Line 1: Two integers V and E (microservices and direct RPC links).
Next E lines: Two integers u and v denoting directed RPC access from u to v.

Output Format:
V lines: Binary reachability matrix (1 if reachable, 0 otherwise).

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
4 4
1 2
2 3
3 1
3 4

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Transitive Closure Reachability Matrix:
1 1 1 1
1 1 1 1
1 1 1 1
0 0 0 1
================================================================================
*/

#include <iostream>
#include <vector>

using namespace std;

int main() {
    int v, e;
    if (!(cin >> v >> e)) return 0;

    vector<vector<int>> reach(v + 1, vector<int>(v + 1, 0));

    for (int i = 1; i <= v; i++) reach[i][i] = 1; // Self-reachability

    for (int i = 0; i < e; i++) {
        int u, to;
        cin >> u >> to;
        reach[u][to] = 1;
    }

    for (int k = 1; k <= v; k++) {
        for (int i = 1; i <= v; i++) {
            for (int j = 1; j <= v; j++) {
                reach[i][j] = reach[i][j] || (reach[i][k] && reach[k][j]);
            }
        }
    }

    cout << "Transitive Closure Reachability Matrix:\n";
    for (int i = 1; i <= v; i++) {
        for (int j = 1; j <= v; j++) {
            cout << reach[i][j] << (j == v ? "" : " ");
        }
        cout << "\n";
    }

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Initialize reach[i][j] = 1 if edge (i, j) exists or i == j; else 0.
2. Warshall's recurrence using boolean OR/AND:
   reach[i][j] = reach[i][j] OR (reach[i][k] AND reach[k][j]).
3. Path exists from i to j through intermediate vertices {1...k} if a direct path already exists OR if i reaches k AND k reaches j.

Edge Cases:
- Disconnected graph: Components remain mutually unreachable (0).
- Strongly connected components: Entire submatrix populated with 1s.

Complexity Analysis:
- Time Complexity: O(V^3) (can be optimized to O(V^3 / 64) using bitsets).
- Space Complexity: O(V^2) boolean reachability matrix.
================================================================================
*/
