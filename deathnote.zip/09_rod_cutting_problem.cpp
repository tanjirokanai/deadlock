/*
================================================================================
Topic: Rod Cutting Problem
Module / Unit: Dynamic Programming
================================================================================
Scenario Description:
A steel manufacturing facility cuts long steel bars of length L. Cutting into pieces of length i (1 <= i <= L) 
yields market price price[i]. Find the cutting configuration that maximizes gross revenue.

Input Format:
Line 1: An integer L (length of steel rod).
Line 2: L space-separated integers representing price of rod of length 1, 2, ..., L.

Output Format:
Line 1: Maximum Revenue.
Line 2: Optimal cut lengths.

--------------------------------------------------------------------------------
Sample Input:
--------------------------------------------------------------------------------
8
1 5 8 9 10 17 17 20

--------------------------------------------------------------------------------
Expected Output:
--------------------------------------------------------------------------------
Maximum Revenue: 22
Optimal cut lengths: 2 6
================================================================================
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int L;
    if (!(cin >> L)) return 0;

    vector<int> price(L + 1);
    for (int i = 1; i <= L; i++) cin >> price[i];

    vector<int> r(L + 1, 0);
    vector<int> s(L + 1, 0);

    for (int j = 1; j <= L; j++) {
        int max_val = -1;
        for (int i = 1; i <= j; i++) {
            if (max_val < price[i] + r[j - i]) {
                max_val = price[i] + r[j - i];
                s[j] = i;
            }
        }
        r[j] = max_val;
    }

    cout << "Maximum Revenue: " << r[L] << "\n";
    cout << "Optimal cut lengths: ";
    int temp = L;
    while (temp > 0) {
        cout << s[temp] << (temp - s[temp] > 0 ? " " : "");
        temp -= s[temp];
    }
    cout << "\n";

    return 0;
}

/*
================================================================================
THEORY, WORKING & COMPLEXITY ANALYSIS:
================================================================================
Algorithm & Working Mechanism:
1. Subproblem: r[j] represents maximum revenue obtainable for rod of length j.
2. Recurrence:
   r[j] = max_{1 <= i <= j} (price[i] + r[j - i])
3. Store the optimal initial cut length in s[j] to allow linear-time reconstruction of all cut segments.
4. Solved iteratively in bottom-up order from j = 1 to L.

Edge Cases:
- Length L = 0: Revenue = 0.
- Piece prices strictly linear (price[i] = k * i): No cut preference; any partition yields same value.
- Whole uncut rod price is maximum: Single piece of length L chosen.

Complexity Analysis:
- Time Complexity: O(L^2) since j steps perform j iterations (1 + 2 + ... + L = L(L+1)/2).
- Space Complexity: O(L) for revenue and split arrays.
================================================================================
*/
